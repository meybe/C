# -*- coding: utf-8 -*-
import LINETCR
from LINETCR.lib.curve.ttypes import *
from datetime import datetime
import ast,re,time,random,sys,json,codecs,threading,glob,tempfile,io
from gtts import gTTS
from time import sleep
import os,six, urllib, wikipedia, requests, bs4, html5lib
import time,random,sys,re,subprocess,string,codecs,ctypes
from bs4 import BeautifulSoup
from PIL import Image

with open('token.json', 'r') as fp:
    akun = json.load(fp)

cl = LINETCR.LINE()
#cl.login(token='EqBUGcqIyrLqytmU49Tc.ueLeCJvKvdpbtVTadGiEla.CJ6sd4PpUqWEaoPJoExKI4IcnrdmiRu3L2QlNkh6fuY=')

k1 = LINETCR.LINE()
#k1.login(token='EqWm2DJeawhzle7ShwR7.3SO9xXO0VOYrY9ZWQuS6rW.m8sSiO5RjRkljs+RBQ+sNNKwMrJ+3ixStZjcqzXmpZs=')

k2 = LINETCR.LINE()
#k2.login(token='EqdHxwEBR9VVBWrBizO5.4prOWMYKe6mtKXLKYIIuDq.9brwtspRr7mKqNeDCgaJqgRFeEHV8TNOSi9AHnl90Wk=') 

k3 = LINETCR.LINE()
#k3.login(token='Eq4OcFqPuKSEZqRgIu33.tDMILNRhnwN89+mt2OOeyW.sRG27xswzB+xYhzfUJLEr6BpVuFa2aEuHtPdkEL35lI=')

k4 = LINETCR.LINE()
#k4.login(token='Eqs1GCRPILbJ8v7zDWmd.sWb83FC6zfP+k+ArrujPtq.GupnIZDMPkESDXClLde6ENUelnXrcch2KAKVJ531EfY=')

k5 = LINETCR.LINE()
#k5.login(token='EqnYrsbkkXq3sF123Mha.TtmrXEUy+dQxPJqjuRhwUG.TO3Lx/fiUKfWY5Hgn45JGTOzWngSYrUgMdoUgx6522o=')

k6 = LINETCR.LINE()
#k6.login(token='Eqk5yjhdhwGIMRIQSqH4.K4ZdSmCEofQe1bhu08sm1a.EOs5hvV0PYslSdFgib20NWTJI0p985euXO7Jdf19mLc=')

k7 = LINETCR.LINE()
#k7.login(token='EqVp5R9DM1Vwovj9c943.q+F0eZivv+xVfDH8RQIIuW.Snj3/ED8ity3qgHp3XwzQkcnWfIBzrXFb2Xft/antXs=')

k8 = LINETCR.LINE()
#k8.login(token='Eq2NuTnVxVxps1NdWNh9.Z5La8y0aL0C+/9hu2gh+6q.PGCVL135Vu+n+TXaEvbjaud2aOCmmJ4hDIhccvvb0Qw=')

k9 = LINETCR.LINE()
#k9.login(token='Eq4HAmUjwdzwH7Be6wj8.R5j08fM3a6RuHnyR0+8ZIa.2Whr7ezc+5rggho710W4S+1heCdETONYvIWjCeGWQA4=')
k10 = LINETCR.LINE()
#k10.login(token='EqhG57CUOaX9xUOE9NGf.HiL61WaehMubtiyBo4P5hW.P0J0cmEzZ8r/A1DgRlMQs9gKDZmUq3Th//ILh+5VOaY=')


if akun['token1'] == "EqBUGcqIyrLqytmU49Tc.ueLeCJvKvdpbtVTadGiEla.CJ6sd4PpUqWEaoPJoExKI4IcnrdmiRu3L2QlNkh6fuY=":        
cl.login(token='EqBUGcqIyrLqytmU49Tc.ueLeCJvKvdpbtVTadGiEla.CJ6sd4PpUqWEaoPJoExKI4IcnrdmiRu3L2QlNkh6fuY=')
else:                                                                                                                             
    cl.login(token=akun['token1'])                                                                                      if akun['token2'] == "EqWm2DJeawhzle7ShwR7.3SO9xXO0VOYrY9ZWQuS6rW.m8sSiO5RjRkljs+RBQ+sNNKwMrJ+3ixStZjcqzXmpZs=":
    k1.login(token='EqWm2DJeawhzle7ShwR7.3SO9xXO0VOYrY9ZWQuS6rW.m8sSiO5RjRkljs+RBQ+sNNKwMrJ+3ixStZjcqzXmpZs=')
else:
    k1.login(token=akun['token2'])
if akun['token3'] == "EqdHxwEBR9VVBWrBizO5.4prOWMYKe6mtKXLKYIIuDq.9brwtspRr7mKqNeDCgaJqgRFeEHV8TNOSi9AHnl90Wk=":
    k2.login(token='EqdHxwEBR9VVBWrBizO5.4prOWMYKe6mtKXLKYIIuDq.9brwtspRr7mKqNeDCgaJqgRFeEHV8TNOSi9AHnl90Wk=')          else:
    k2.login(token=akun['token3'])
if akun['token4'] == "Eq4OcFqPuKSEZqRgIu33.tDMILNRhnwN89+mt2OOeyW.sRG27xswzB+xYhzfUJLEr6BpVuFa2aEuHtPdkEL35lI=":
    k3.login(token='Eq4OcFqPuKSEZqRgIu33.tDMILNRhnwN89+mt2OOeyW.sRG27xswzB+xYhzfUJLEr6BpVuFa2aEuHtPdkEL35lI=')
else:                                                                                                                           
    k3.login(token=akun['token4'])                                                                                      if akun['token5'] == "Eqs1GCRPILbJ8v7zDWmd.sWb83FC6zfP+k+ArrujPtq.GupnIZDMPkESDXClLde6ENUelnXrcch2KAKVJ531EfY=":
    k4.login(token='Eqs1GCRPILbJ8v7zDWmd.sWb83FC6zfP+k+ArrujPtq.GupnIZDMPkESDXClLde6ENUelnXrcch2KAKVJ531EfY=')
else:
    k4.login(token=akun['token5'])
if akun['token6'] == "EqnYrsbkkXq3sF123Mha.TtmrXEUy+dQxPJqjuRhwUG.TO3Lx/fiUKfWY5Hgn45JGTOzWngSYrUgMdoUgx6522o=":
    k5.login(token='EqnYrsbkkXq3sF123Mha.TtmrXEUy+dQxPJqjuRhwUG.TO3Lx/fiUKfWY5Hgn45JGTOzWngSYrUgMdoUgx6522o=')
else:
    k5.login(token=akun['token6'])
if akun['token7'] == "Eqk5yjhdhwGIMRIQSqH4.K4ZdSmCEofQe1bhu08sm1a.EOs5hvV0PYslSdFgib20NWTJI0p985euXO7Jdf19mLc=":
    k6.login(token='Eqk5yjhdhwGIMRIQSqH4.K4ZdSmCEofQe1bhu08sm1a.EOs5hvV0PYslSdFgib20NWTJI0p985euXO7Jdf19mLc=')
else:                                                                                                                                      
    k6.login(token=akun['token7'])
if akun['token8'] == "EqVp5R9DM1Vwovj9c943.q+F0eZivv+xVfDH8RQIIuW.Snj3/ED8ity3qgHp3XwzQkcnWfIBzrXFb2Xft/antXs=":
    k7.login(token='EqVp5R9DM1Vwovj9c943.q+F0eZivv+xVfDH8RQIIuW.Snj3/ED8ity3qgHp3XwzQkcnWfIBzrXFb2Xft/antXs=')
else:
    k7.login(token=akun['token8'])
if akun['token9'] == "Eq2NuTnVxVxps1NdWNh9.Z5La8y0aL0C+/9hu2gh+6q.PGCVL135Vu+n+TXaEvbjaud2aOCmmJ4hDIhccvvb0Qw=":
    k8.login(token='Eq2NuTnVxVxps1NdWNh9.Z5La8y0aL0C+/9hu2gh+6q.PGCVL135Vu+n+TXaEvbjaud2aOCmmJ4hDIhccvvb0Qw=')
else:
    k8.login(token=akun['token9'])
if akun['token10'] == "Eq4HAmUjwdzwH7Be6wj8.R5j08fM3a6RuHnyR0+8ZIa.2Whr7ezc+5rggho710W4S+1heCdETONYvIWjCeGWQA4=":
    k9.login(token='Eq4HAmUjwdzwH7Be6wj8.R5j08fM3a6RuHnyR0+8ZIa.2Whr7ezc+5rggho710W4S+1heCdETONYvIWjCeGWQA4=')
else:
    k9.login(token=akun['token10'])
if akun['token11'] == "EqhG57CUOaX9xUOE9NGf.HiL61WaehMubtiyBo4P5hW.P0J0cmEzZ8r/A1DgRlMQs9gKDZmUq3Th//ILh+5VOaY=":
    k10.login(token='EqhG57CUOaX9xUOE9NGf.HiL61WaehMubtiyBo4P5hW.P0J0cmEzZ8r/A1DgRlMQs9gKDZmUq3Th//ILh+5VOaY=')
else:
    k10.login(token=akun['token11'])

    
cl.loginResult()
k1.loginResult()
k2.loginResult()
k3.loginResult()
k4.loginResult()
k5.loginResult()
k6.loginResult()
k7.loginResult()
k8.loginResult()
k9.loginResult()
k10.loginResult()

print ("login success")

KAC=[k1,cl,k2,k4,k3,k6,k5,k8,k7,k10,k9]
mid = cl.getProfile().mid
k1mid = k1.getProfile().mid
k2mid = k2.getProfile().mid
k3mid = k3.getProfile().mid
k4mid = k4.getProfile().mid
k5mid = k5.getProfile().mid
k6mid = k6.getProfile().mid
k7mid = k7.getProfile().mid
k8mid = k8.getProfile().mid
k9mid = k9.getProfile().mid
k10mid = k10.getProfile().mid
print ("Main BOT " + mid)
akun['token1'] = cl.authToken
print ("Assist BOT: " + k1mid)
akun['token2'] = k1.authToken
print ("Assist BOT: " + k2mid)
akun['token3'] = k2.authToken
print ("Assist BOT: " + k3mid)
akun['token4'] = k3.authToken
print ("Assist BOT: " + k4mid)
akun['token5'] = k4.authToken
print ("Assist BOT: " + k5mid)
akun['token6'] = k5.authToken
print ("Assist BOT: " + k6mid)
akun['token7'] = k6.authToken
print ("Assist BOT: " + k7mid)
akun['token8'] = k7.authToken
print ("Assist BOT: " + k8mid)
akun['token9'] = k8.authToken
print ("Assist BOT: " + k9mid)
akun['token10'] = k9.authToken
print ("Assist BOT: " + k9mid)
akun['token11'] = k10.authToken
with open('token.json', 'w') as fp:
    json.dump(akun, fp, sort_keys=True, indent=4)

Bots=[mid,k1mid,k2mid,ki3mid,ki4mid,ki5mid,ki6mid,ki7mid,ki8mid,ki9mid,ki10mid]
wbanlist = []
inviting = False
notag = False
changeimage = False
changeimage1 = False

backup = cl.getProfile()
backup1 = k1.getProfile()
backup2 = k2.getProfile()
backup3 = k3.getProfile()
backup4 = k4.getProfile()
backup5 = k5.getProfile()
backup6 = k6.getProfile()
backup7 = k7.getProfile()
backup8 = k8.getProfile()
backup9 = k9.getProfile()
backup10 = k10.getProfile()
strt = datetime.now()

periksa = {
        'autojoin':"off",
    'addbanmode':{},
    'delbanmode':{},
    'banlist':{},
    'addfriend':{},
        'autocancel':{},
        'autopurge':{},
        'lockqr':{},
        'linkpro':{},
        "pjoin":{},        
        'picon':{},
        'gname':{},
        'proname':{},                		
    'liketl':{},
        'wl':{},
        'addwl':{},
        'delwl':{},
    'undang':{},
        'tmimic':{},
        'mimic':False,
        'message':"",
        'autolike':False,
        'autoadd':False,
        'autorejc':False
}
wait = {
    'contact':False,
    'autoJoin':True,
    'autoCancel':{"on":True,"members":1},
    'leaveRoom':True,
    'timeline':False,
    'autoAdd':False,
    'message':"",
    "lang":"JP",
    "comment":"",
    "welmsg":"welcome to group",    
    "likeOn":False,
    "commentOn":False,
    "commentBlack":{},
    "tag":False,
    "clock":False,
    "cName":"",
    "pname":{},    
    "pro_name":{},  
    "detectMention":False,
    "kickMention":False,        
    "cancelprotect":False,
    "welcomeOn":False,
    "welmsg":False, 
    "inviteprotect":False,
   }
sider = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
    }
  
setTime = {}
setTime = sider['setTime']

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

wait2 = {
    "readPoint":{},
    "readMember":{},
    "setTime":{},
    "ROM":{}
    }

setTime = {}
setTime = wait2['setTime']
mulai = time.time() 

with open('settingan.json', 'r') as fp:
    periksa = json.load(fp)
with open('sider.json', 'r') as fp:
    sider = json.load(fp)

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

agent = {'user-Agent': "Mozilla/4.0(compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50/27; .NET CLR 3.0.04506.0)"} 

def translate(to_translate, to_language="auto", language="auto"):
    base_link="http://translate.google.com/m?hl=%s&sl=%s&q=%s"
    if(six.PY2):
        link = base_link % (to_language, language, urllib.pathname2url(to_translate))
        request = urllib2.Request(link, headers=agent)
        page = urllib2.urlopen(request).read()
    else:
        link = base_link % (to_language, language, urllib.parse.quote(to_translate))
        request = urllib.request.Request(link, headers=agent)
        page = urllib.request.urlopen(request).read()
    expr = r'class="t0">(.*?)<'
    result = re.findall(expr,page)
    if(len(result)==0):
        return("")
    return(result[0])

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib.request.Request(url, headers = headers)
            resp = urllib.request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"
            
def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    
        end_quote = 0
        link = "no_links"
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+1)
        end_content = s.find(',"ow"',start_content+1)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content
        
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items

def MENTION(to, nama):
    zx = ""
    zxc = ""
    nm = nama
    for x in nm:
        pesan = ''
        pesan2 = pesan+"@a\n"
        xlen = str(len(zxc))
        xlen2 = str(len(zxc)+len(pesan2)-1)
        zx += """{"S":"""+json.dumps(xlen)+""","E":"""+json.dumps(xlen2)+""","M":"""+json.dumps(x)+"},"""
        
        zxc += pesan2
    zx = (zx[:int(len(zx)-1)])
    print (zx)
    msg = Message()
    msg.to = to
    msg.text = zxc
    msg.contentMetadata = {'MENTION':'{"MENTIONEES":['+zx+']}','EMTVER':'4'}
    try:
        cl.sendMessage(msg)
    except Exception as e:
        print (e)
        
def summon(to, nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    #print "[Command] Tag All"
    try:
       cl.sendMessage(msg)
    except Exception as error:
       print (error)
def kick_all(to,target):
                    msg = Message()
                    msg.to = to
                    try:
                                kb.kickoutFromGroup(msg.to,[target])
                    except:
                                pass

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def bot(op):
    global notag
    global changeimage
    global changeimage1    
╔═══════════════════
║༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻
╠═══════════════════
║            ʜᴇʟᴘ menu
╠═══════════════════
║☆ 「 ᴍʏʜᴇʟᴘ」
║☆ 「 ᴍʏsᴇᴛ」
║☆ 「 ᴍʏʙᴏᴛs」
║☆ 「 ᴀʟʟʙᴏᴛs」
║☆ 「 ᴍᴇ」
║☆ 「 ᴍɪᴅ」
║☆ 「 ᴀʟʟᴍɪᴅ」
║☆ 「 ɢɪᴅ」
║☆ 「 ᴍʏɢʀᴏᴜᴘs」
║☆ 「 ᴋᴏɴᴛᴀᴋ: 'ᴍɪᴅ'」
║☆ 「 ᴍᴇssᴀɢᴇ ᴄʜᴀɴɢᴇ: 'ᴛᴇxᴛ'」
║☆ 「 ᴍᴇssᴀɢᴇ ᴄᴇᴋ」
║☆ 「 ʀᴇʙᴏᴏᴛ」
║☆ 「 sᴀʏ 'ᴛᴇxᴛ'」
║☆ 「 ᴍᴜsɪᴄ 'ᴛᴇxᴛ'」
║☆ 「 ʟɪʀɪᴋ」
║☆ 「 ᴘɪᴄᴛ ɪɢ 'ʟɪɴᴋ'」
║☆ 「 ᴄs: 'sᴛᴀᴛᴜs'」
║☆ 「 ᴄɴ: 'ɴᴀᴍᴇ'」
║☆ 「 ɢᴄ」
║☆ 「 sᴛᴀғғᴀᴅᴅ @」
║☆ 「 ᴇxᴘᴇʟsᴛᴀғғ @」
║☆ 「 sᴛᴀғғʟɪsᴛ」
║☆ 「 ᴄʟᴇᴀʀsᴛᴀғғ」
║☆ 「 ᴀʟʟ ᴘɪᴄᴛ」
║☆ 「 ᴍʏᴘɪᴄᴛ」
║☆ 「 ᴍʏᴄᴏᴠᴇʀ」
║☆ 「 ᴛɪᴍᴇs」
║☆ 「 ᴍʏɴᴀᴍᴇ」
║☆ 「 ᴍʏʙɪᴏ」
║☆ 「 ᴄᴏᴘʏ @ᴛᴀɢ」
║☆ 「 ʙᴀᴄᴋᴜᴘ」
║☆ 「 ʙʀᴏ」
║☆ 「 ʙʏᴇ」
║☆ 「 ʀᴇsᴘᴏɴ」
║☆ 「 ᴘɪɴɢ」
║☆ 「 ʀɢʀᴏᴜᴘs」
║☆ 「 ᴡʙᴀɴ: 'ᴛᴇxᴛ'」
║☆ 「 ᴡᴜɴʙᴀɴ: 'ᴛᴇxᴛ'」
║☆ 「 ᴡʙᴀɴʟɪsᴛ」
║☆ 「 ɢɪғᴛ:ᴏɴ」
║☆ 「 ᴠᴏɪᴄᴇ: 'ᴛᴇxᴛ'」
║☆ 「 ᴛᴀɢᴍᴇᴍ」
║☆ 「 ᴛᴀɢ」
║☆ 「 ɴᴏᴛᴀɢ」
║☆ 「 ʙᴄɢʀᴏᴜᴘ: 」
║☆ 「 ᴘɪᴄᴛɢʀᴏᴜᴘs」
║☆ 「 ᴄʜᴀɴɢᴇ ᴘɪᴄᴛ」
║☆ 「 ᴄʜᴀɴɢᴇ ᴘɪᴄᴛ ɢʀᴏᴜᴘ」
║☆ 「 sᴘᴀᴍ 'ᴛᴇxᴛ'」
║☆ 「 ɢᴇᴛᴀʟʟ @ᴛᴀɢ」
║☆ 「 ᴄᴏɴᴛᴀᴄᴛ @ᴛᴀɢ」
║☆ 「 sᴛᴀᴛᴜs @ᴛᴀɢ」
║☆ 「 ᴜᴘᴡᴇʟᴄᴏᴍᴇ」
║☆ 「 ᴄʜᴇᴄᴋ ᴡᴇʟᴄᴏᴍᴇ」
║☆ 「 ᴡᴇʟᴄᴏᴍᴇ」
║☆ 「 ɪɴᴠɪᴛᴇ:ᴏɴ」
║☆ 「 ɢᴇᴛɪɴғᴏ」
║☆ 「 ᴛᴀɢ @」
║☆ 「 ᴍɪᴅ @ᴛᴀɢ」
║☆ 「 ᴘɪᴄᴛ @ᴛᴀɢ」
║☆ 「 ᴄᴏᴠᴇʀ @ᴛᴀɢ」
║☆ 「 ᴜɴᴀᴍᴇ @ᴛᴀɢ」
║☆ 「 ᴀᴅᴅᴍɪᴍɪᴄ @ᴛᴀɢ」
║☆ 「 ᴜɴᴍɪᴍɪᴄ @ᴛᴀɢ」
║☆ 「 ᴍɪᴍɪᴄʟɪsᴛ」
║☆ 「 ʙᴀɴ @ᴛᴀɢ」
║☆ 「 ᴜɴʙᴀɴ @ᴛᴀɢ」
║☆ 「 ᴄᴇᴋ ʙᴀɴ」
║☆ 「 ᴋɪʟʟʙᴀɴ」
║☆ 「 ᴄʟᴇᴀʀ ʙᴀɴ」
║☆ 「 ᴋɪᴄᴋ @ᴛᴀɢ」
║☆ 「 ᴠᴋɪᴄᴋ @ᴛᴀɢ」
║☆ 「 ᴍᴀʏʜᴇᴍ」
╠═══════════════════
║            ʜᴇʟᴘ sᴇᴛᴛɪɴɢ
╠═══════════════════
║☆ 「 sᴛᴀғғᴀᴅᴅ:ᴏɴ」
║☆ 「 ᴇxᴘᴇʟsᴛᴀғғ:ᴏɴ」
║☆ 「 ʙᴀɴ:ᴏɴ/ᴏғғ」
║☆ 「 ᴜɴʙᴀɴ:ᴏɴ/ᴏғғ」
║☆ 「 ᴍɪᴍɪᴄ:ᴏɴ/ᴏғғ」
║☆ 「 ʟɪɴᴋ ᴏɴ/ᴏғғ」
║☆ 「 sɪᴅᴇʀ ᴏɴ/ᴏғғ」
║☆ 「 sᴇᴛ ᴏɴ/ᴏғғ」
║☆ 「 ᴠɪᴇᴡ」
║☆ 「 ᴡᴇʟᴄᴏᴍᴇ:ᴏɴ/ᴏғғ」
║☆ 「 ᴀᴜᴛᴏᴊᴏɪɴ:ᴏɴ/ᴏғғ」
║☆ 「 ᴀᴜᴛᴏᴀᴅᴅ:ᴏɴ/ᴏғғ」
║☆ 「 ᴀᴜᴛᴏʟɪᴋᴇ:ᴏɴ/ᴏғғ」
║☆ 「 ᴀᴜᴛᴏᴘᴜʀɢᴇ:ᴏɴ/ᴏғғ」
║☆ 「 ʙʟᴏᴄᴋ ǫʀ:ᴏɴ/ᴏғғ」
║☆ 「 ʙʟᴏᴄᴋɪɴᴠɪᴛᴇ:ᴏɴ/ᴏғғ」
║☆ 「 ᴘʀᴏᴛᴇᴄᴛɪᴏɴ:ᴏɴ/ᴏғғ」
║☆ 「 ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ:ᴏɴ/ᴏғғ」
╠═══════════════════
║༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻&
║✍Ŧ€₳M☬ж☬Ħ₳ʗҜ฿❂Ŧ✈๛
╚═══════════════════
"""
    try:
        
        if op.type == 0:
            return
        if op.type == 5:
            if periksa['autoadd'] == True:
                cl.findAndAddContactsByMid(op.param1)
                if (periksa["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(periksa["message"]))
            else:
                pass
        if op.type == 55:
                try:
                    if cctv['cyduk'][op.param1]==True:
                        if op.param1 in cctv['point']:
                            Name = cl.getContact(op.param2).displayName
                            if Name in cctv['sidermem'][op.param1]:
                                pass
                            else:
                                cctv['sidermem'][op.param1] += "\n• " + Name
                                if " " in Name:
                                    nick = Name.split(' ')
                                    if len(nick) == 2:
                                        cl.sendText(op.param1, "Haii " +  nick[0] +  "\nNgintip Aja Niih. . .\nChat Kek Idiih (-__-)   ")
                                        MENTION(op.param1,[op.param2])
                                    else:
                                        cl.sendText(op.param1, "Haii " +  nick[1] + "\nBetah Banget Jadi Penonton. . .\nChat Napa (-__-)   ")
                                        MENTION(op.param1,[op.param2])  
                                else:
                                    cl.sendText(op.param1, "Haii " + Name +  "\nNgapain Kak Ngintip Aja???\nSini Gabung Chat...   ")
                                    MENTION(op.param1,[op.param2])
                        else:
                            pass
                    else:
                        pass
                except:
                    pass
        else:
            pass

        if op.type == 11:
          if op.param1 in periksa["lockqr"]:
             if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                X = cl.getGroup(op.param1)
                if X.preventJoinByTicket == False:
                  X.preventJoinByTicket = True
                  cl.updateGroup(X)
                  if op.param2 in periksa["banlist"]:
                    cl.kickoutFromGroup(op.param1,[op.param2])
                  else:
                    periksa["banlist"][op.param2] = True
                    with open('settingan.json', 'w') as fp:
                      json.dump(periksa, fp, sort_keys=True, indent=4)                      
          if op.param1 in periksa["gname"]:
              group = cl.getGroup(op.param1)
              try:
                  G = cl.getGroup(op.param1)
              except:
                  pass
              G.name = periksa['proname'][op.param1]
              try:
                  cl.updateGroup(G)
              except:
                  pass
              if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                  try:
                      kicker=random.choice(KAC)
                      kicker.kickoutFromGroup(op.param1,[op.param2])
                  except:
                      try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                      except:
                          cl.kickoutFromGroup(op.param1,[op.param2])
              else:
                  periksa["banlist"][op.param2] = True
                  with open('settingan.json', 'w') as fp:
                      json.dump(periksa, fp, sort_keys=True, indent=4)                      
        if op.type == 11:
          if op.param1 in periksa["linkpro"]:
             if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                X = cl.getGroup(op.param1)
                if X.preventJoinByTicket == False:
                  X.preventJoinByTicket = True
                  Ticket = cl.reissueGroupTicket(op.param1)
                  k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                  k6.kickoutFromGroup(op.param1,[op.param2])
                  cl.updateGroup(X)
                  k6.leaveGroup(op.param1)
                  cl.sendText(msg.to, "Do not open QR")                  
                  if op.param2 in periksa["banlist"]:
                    k6.kickoutFromGroup(op.param1,[op.param2])
                  else:
                    periksa["banlist"][op.param2] = True
                    with open('settingan.json', 'w') as fp:
                      json.dump(periksa, fp, sort_keys=True, indent=4)
        if op.type == 17:
           if op.param1 in periksa["pjoin"]:
               if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                   random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])                                                                                        				  
        if op.type == 17:
          if op.param1 in periksa["autopurge"]:
            G = cl.getGroup(op.param1)
            if G is None:
                pass
            else:
                gMembMids = [contact.mid for contact in G.members]
                matched_list = []
                for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                if matched_list == []:
                        pass
                for jj in matched_list:
                    try:
                        k1.kickoutFromGroup(op.param1,[jj])
                        k2.kickoutFromGroup(op.param1,[jj])
                        k3.kickoutFromGroup(op.param1,[jj])
                        k4.kickoutFromGroup(op.param1,[jj])						
                    except:
                      try:
                        k5.kickoutFromGroup(op.param1,[jj])
                      except:
                            cl.kickoutFromGroup(op.param1,[jj])							
        if op.type == 17:
            if wait["welcomeOn"] == True:
                 ginfo = cl.getGroup(op.param1)
                 contact = cl.getContact(op.param2)
                 image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus                 
                 cl.sendText(op.param1,cl.getContact(op.param2).displayName +"\n"+ wait["welmsg"])
                 cl.sendImageWithUrl(op.param1,image)                                  
#----------[Welcome]----------------------------        
        if op.type == 15:
          if wait["welcomeOn"] == True:     
            cl.sendText(op.param1,"Goodbye " + cl.getContact(op.param2).displayName)
        if op.type == 13:
            if mid in op.param3:
              if periksa["autojoin"] == "wl":
                if op.param2 in periksa["wl"]:
                  cl.acceptGroupInvitation(op.param1)
                else:
                    if periksa['autorejc'] == True:
                        cl.rejectGroupInvitation(op.param1)
                    else:
                        pass
              elif periksa["autojoin"] == "all":
                  cl.acceptGroupInvitation(op.param1)
              else:
                  if periksa['autorejc'] == True:
                        cl.rejectGroupInvitation(op.param1)
                  else:
                        pass
            
            else:
                if op.param2 not in Bots and op.param2 not in periksa["wl"]:
                  group_id=op.param1
                  if group_id in periksa["autocancel"]:
                    group = cl.getGroup(op.param1)
                    if group.invitee is None:
                       pass
                    else:
                        gInviMids = [contact.mid for contact in group.invitee]
                        try:
                            kicker=random.choice(KAC)
                            kicker.cancelGroupInvitation(op.param1, gInviMids)
                        except:
                            try:
                                kicker=random.choice(KAC)
                                kicker.cancelGroupInvitation(op.param1, gInviMids)
                            except:
                                cl.cancelGroupInvitation(op.param1, gInviMids)
                                
                if op.param1 in periksa["autopurge"]:        
                    Inviter = op.param3.replace("",',')
                    InviterX = Inviter.split(",")
                    matched_list = []
                    for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, InviterX)
                    if matched_list == []:
                        pass
                    else:
                        k1.cancelGroupInvitation(op.param1, matched_list)
            
        if op.type == 19:
            if op.param1 in periksa["protect"]:
                if op.param2 not in Bots and op.param2 not in periksa['wl']:
                    try:
                        k1.kickoutFromGroup(op.param1,[op.param2])
                        k2.kickoutFromGroup(op.param1,[op.param2])
                        k3.kickoutFromGroup(op.param1,[op.param2])
                        k4.kickoutFromGroup(op.param1,[op.param2])		
				
k5.kickoutFromGroup(op.param1,[op.param2])
                        k6.kickoutFromGroup(op.param1,[op.param2])
                        k7.kickoutFromGroup(op.param1,[op.param2])
                        k8.kickoutFromGroup(op.param1,[op.param2])
                        k9.kickoutFromGroup(op.param1,[op.param2])		
                    except:
                        try:
                            k10.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                try:
                        k1.inviteIntoGroup(op.param1,[op.param3])
                        k2.inviteIntoGroup(op.param1,[op.param3])
                        k3.inviteIntoGroup(op.param1,[op.param3])
                        k4.inviteIntoGroup(op.param1,[op.param3])

k5.inviteIntoGroup(op.param1,[op.param3])
                        k6.inviteIntoGroup(op.param1,[op.param3])
                        k7.inviteIntoGroup(op.param1,[op.param3])
                        k8.inviteIntoGroup(op.param1,[op.param3])						
                        k9.inviteIntoGroup(op.param1,[op.param3])						

                except:
                        try:
                            k10.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            cl.inviteIntoGroup(op.param1,[op.param3])
                if op.param2 in periksa["banlist"]:
                        pass
                elif op.param2 in periksa["wl"]:
                  pass 
                else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)                 
            if mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k4.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = k1.getGroup(op.param1)
                     except:
                         try:
                             G = k2.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k5.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         k1.updateGroup(G)
                         Ti = k1.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k2.updateGroup(G)
                             Ti = k2.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k5.updateGroup(G)
                                         Ti = k5.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass                                                              	
                     cl.acceptGroupInvitationByTicket(op.param1,Ti)
                     X = cl.getGroup(op.param1)
                     X.preventJoinByTicket = True
                     cl.updateGroup(X)
                     Ti = cl.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass
                     else:
                        periksa["banlist"][op.param2] = True
            if k1mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k3.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k2.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k5.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k2.updateGroup(G)
                             Ti = k2.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k5.updateGroup(G)
                                         Ti = k5.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k1.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k1.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k1.updateGroup(G)
                     Ticket = k1.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
            if k2mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k1.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k1.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k5.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k1.updateGroup(G)
                             Ti = k1.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k5.updateGroup(G)
                                         Ti = k5.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k2.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k2.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k2.updateGroup(G)
                     Ticket = k2.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
            if k3mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k4.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k1.getGroup(op.param1)
                         except:
                             try:
                                 G = k2.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k5.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k1.updateGroup(G)
                             Ti = k1.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k2.updateGroup(G)
                                 Ti = k2.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k5.updateGroup(G)
                                         Ti = k5.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k3.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k3.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k3.updateGroup(G)
                     Ticket = k3.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
            if k4mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k2.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k1.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k2.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k5.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k1.updateGroup(G)
                             Ti = k1.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k2.updateGroup(G)
                                     Ti = k2.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k5.updateGroup(G)
                                         Ti = k5.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k4.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k4.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k4.updateGroup(G)
                     Ticket = k4.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
            if k5mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k3.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k1.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k2.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k1.updateGroup(G)
                             Ti = k1.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k2.updateGroup(G)
                                         Ti = k2.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k5.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k5.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k5.updateGroup(G)
                     Ticket = k5.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
            if k6mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k3.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k1.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k2.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k1.updateGroup(G)
                             Ti = k1.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k2.updateGroup(G)
                                         Ti = k2.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k6.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k6.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k6.updateGroup(G)
                     Ticket = k6.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)		
            if k7mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k3.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k1.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k2.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k1.updateGroup(G)
                             Ti = k1.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k2.updateGroup(G)
                                         Ti = k2.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k7.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k7.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k7.updateGroup(G)
                     Ticket = k7.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)		
            if k8mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k3.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k1.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k2.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k1.updateGroup(G)
                             Ti = k1.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k2.updateGroup(G)
                                         Ti = k2.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k8.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k8.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k8.updateGroup(G)
                     Ticket = k8.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)		
            if k9mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k3.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k1.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k2.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k1.updateGroup(G)
                             Ti = k1.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k2.updateGroup(G)
                                         Ti = k2.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k9.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k9.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k9.updateGroup(G)
                     Ticket = k9.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)	
            if k10mid in op.param3:
                     try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                     except:
                        try:
                          kicker=random.choice(KAC)
                          kicker.kickoutFromGroup(op.param1,[op.param2])
                        except:
                          k3.kickoutFromGroup(op.param1,[op.param2])
                     try:
                         G = cl.getGroup(op.param1)
                     except:
                         try:
                             G = k1.getGroup(op.param1)
                         except:
                             try:
                                 G = k3.getGroup(op.param1)
                             except:
                                 try:
                                     G = k4.getGroup(op.param1)
                                 except:
                                     try:
                                         G = k2.getGroup(op.param1)
                                     except:
                                         try:
                                             G = k6.getGroup(op.param1)
                                         except:
                                             try:
                                                 G = k7.getGroup(op.param1)
                                             except:
                                                 try:
                                                     G = k8.getGroup(op.param1)
                                                 except:
                                                     pass
                     G.preventJoinByTicket = False
                     try:
                         cl.updateGroup(G)
                         Ti = cl.reissueGroupTicket(op.param1)
                     except:
                         try:
                             k1.updateGroup(G)
                             Ti = k1.reissueGroupTicket(op.param1)
                         except:
                             try:
                                 k3.updateGroup(G)
                                 Ti = k3.reissueGroupTicket(op.param1)
                             except:
                                 try:
                                     k4.updateGroup(G)
                                     Ti = k4.reissueGroupTicket(op.param1)
                                 except:
                                     try:
                                         k2.updateGroup(G)
                                         Ti = k2.reissueGroupTicket(op.param1)
                                     except:
                                         try:
                                             k6.updateGroup(G)
                                             Ti = k6.reissueGroupTicket(op.param1)
                                         except:
                                             try:
                                                 k7.updateGroup(G)
                                                 Ti = k7.reissueGroupTicket(op.param1)
                                             except:
                                                 try:
                                                     k8.updateGroup(G)
                                                     Ti = k8.reissueGroupTicket(op.param1)
                                                 except:
                                                     pass
                     k10.acceptGroupInvitationByTicket(op.param1,Ti)
                     G = k10.getGroup(op.param1)
                     G.preventJoinByTicket = True
                     k10.updateGroup(G)
                     Ticket = k10.reissueGroupTicket(op.param1)
                     if op.param2 in periksa["banlist"]:
                        pass
                     elif op.param2 in periksa["wl"]:
                        pass 
                     else:
                        periksa["banlist"][op.param2] = True
                        with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
        if op.type == 55:
            try:
                if op.param1 in sider['readPoint']:
            
                    if op.param2 in sider['readMember'][op.param1]:
                        pass
                    else:
                        sider['readMember'][op.param1] += op.param2
                    sider['ROM'][op.param1][op.param2] = op.param2
                    with open('sider.json', 'w') as fp:
                       json.dump(sider, fp, sort_keys=True, indent=4)
                else:
                    pass
            except:
                pass                
        if op.type == 26:
            msg = op.message
            if msg.text:
                if msg.text.lower().lstrip().rstrip() in wbanlist:
                    try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(msg.to,[msg.from_])
                    except:
                        cl.kickoutFromGroup(msg.to,[msg.from_])				
        if op.type == 26:
            msg = op.message
            if msg.contentMetadata:
                if notag:
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    mentionees = [mention['M'] for mention in mentionees]
                    if mid in mentionees:
                        try:
                            kicker=random.choice(KAC)
                            kicker.kickoutFromGroup(msg.to,[msg.from_])
                        except:
                            cl.kickoutFromGroup(msg.to,[msg.from_])
            if msg.text:
                if msg.text.lower().lstrip().rstrip() in wbanlist:
                    try:
                        kicker=random.choice(KAC)
                        kicker.kickoutFromGroup(msg.to,[msg.from_])
                    except:
                        cl.kickoutFromGroup(msg.to,[msg.from_])
            if periksa['mimic'] == True:
                if msg.from_ in periksa['tmimic']:
                    if msg.text.lower() not in helpMessage:
                        cl.sendMessage(msg)
                else:
                    pass
            else:
                pass
        if op.type == 25: #disini :v
            msg = op.message
            pesan = msg.text
            if msg.contentType == 1:
                if changeimage:
                    changeimage = False
                    msgid = msg.id
                    url = "https://obs-de.line-apps.com/os/m/%s"%msgid
                    img = cl.dl_line(url)                  
                    cl.upload_pp(img)                  
                    cl.sendText(msg.to,"Profile image updated.")                   
                if msg.to in periksa["cpp11"]:
                  try:
                   cl.changePP(msg.to, msg.id, mid)
                   del periksa["cpp11"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try: 
                      cl.changePP(msg.to, msg.id, k1mid)
                      del periksa["cpp11"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      cl.sendText(msg.to, "Failed")
                if msg.to in periksa["cpp1"]:
                  try:
                   k1.changePP(msg.to, msg.id, k1mid)
                   del periksa["cpp1"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try: 
                      k1.changePP(msg.to, msg.id, k1mid)
                      del periksa["cpp1"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      k1.sendText(msg.to, "Failed")
                if msg.to in periksa["cpp2"]:
                  try:
                   k2.changePP(msg.to, msg.id, k2mid) 
                   del periksa["cpp2"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try: 
                      k2.changePP(msg.to, msg.id, k2mid)
                      del periksa["cpp2"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      k2.sendText(msg.to, "Failed")
                if msg.to in periksa["cpp3"]:
                  try:
                   k3.changePP(msg.to, msg.id, k3mid) 
                   del periksa["cpp3"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try: 
                      k3.changePP(msg.to, msg.id, k3mid)
                      del periksa["cpp3"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      k3.sendText(msg.to, "Failed")
                if msg.to in periksa["cpp4"]:
                  try:
                   k4.changePP(msg.to, msg.id, k4mid) 
                   del periksa["cpp4"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try: 
                      k4.changePP(msg.to, msg.id, k4mid)
                      del periksa["cpp4"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      k4.sendText(msg.to, "Failed")
                if msg.to in periksa["cpp5"]:
                  try:
                   k5.changePP(msg.to, msg.id, k5mid) 
                   del periksa["cpp5"][msg.to]
                   with open('settingan.json', 'w') as fp:
                     json.dump(periksa, fp, sort_keys=True, indent=4)
                  except Exception as E:
                    print (E)
                    try: 
                      k5.changePP(msg.to, msg.id, k5mid)
                      del periksa["cpp5"][msg.to]
                      with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                    except Exception as E:
                      k5.sendText(msg.to, "Failed")				  
            if msg.contentType == 13:
               global inviting
               if inviting:
                    inviting = False
                    try:
                        kicker=random.choice(KAC)
                        kicker.findAndAddContactsByMid(msg.contentMetadata["mid"])
                        kicker.inviteIntoGroup(msg.to,[msg.contentMetadata["mid"]])
                    except:
                        cl.inviteIntoGroup(msg.to,[msg.contentMetadata["mid"]])			
            if msg.contentType == 13:
               if msg.to in periksa["addbanmode"]:
                  if msg.contentMetadata["mid"] in periksa["banlist"]:
                     cl.sendText(msg.to, "Contact is already in list")
                  elif msg.contentMetadata["mid"] in periksa["wl"]:
                            cl.sendText(msg.to,"Can't banned wl")
                  else:
                        periksa["banlist"][msg.contentMetadata["mid"]] = True
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                        cl.sendText(msg.to, "Added 􀜁􀄯ok􏿿")
               elif msg.to in periksa["delbanmode"]:
                   if msg.contentMetadata["mid"] in periksa["banlist"]:
                        del periksa["banlist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
                   else:
                        cl.sendText(msg.to,"Contact not in list")
              
               elif msg.to in periksa["addwl"]:
                   if msg.contentMetadata["mid"] in periksa["wl"]:
                      cl.sendText(msg.to, "Contact already in list")
                   else:
                        periksa["wl"][msg.contentMetadata["mid"]] = True
                        with open('settingan.json', 'w') as fp:
                              json.dump(periksa, fp, sort_keys=True, indent=4)
                        cl.sendText(msg.to, "Added 􀜁􀄯ok􏿿")
               elif msg.to in periksa["delwl"]:
                   if msg.contentMetadata["mid"] in periksa["wl"]:
                        del periksa["wl"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                   else:
                        cl.sendText(msg.to,"Contact not in list")
               elif msg.to in periksa["addtarget"]:
                   if msg.contentMetadata["mid"] in periksa["target"]:
                      cl.sendText(msg.to, "Contact already in list")
                   else:
                        periksa["target"][msg.contentMetadata["mid"]] = True
                        with open('settingan.json', 'w') as fp:
                              json.dump(periksa, fp, sort_keys=True, indent=4)
                        cl.sendText(msg.to, "Added 􀜁􀄯ok􏿿")
               elif msg.to in periksa["deltarget"]:
                   if msg.contentMetadata["mid"] in periksa["target"]:
                        del periksa["target"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                   else:
                        cl.sendText(msg.to,"Contact not in list")
               elif wait["contact"] == True:
                   msg.contentType = 0
                   cl.sendText(msg.to,msg.contentMetadata["mid"])
                   if 'displayName' in msg.contentMetadata:
                       contact = cl.getContact(msg.contentMetadata["mid"])
                       try:
                           cu = cl.channel.getCover(msg.contentMetadata["mid"])
                       except:
                           cu = ""
                       cl.sendText(msg.to,"[displayName]:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus)
                   else:
                       contact = cl.getContact(msg.contentMetadata["mid"])
                       try:
                           cu = cl.channel.getCover(msg.contentMetadata["mid"])
                       except:
                           cu = ""
                       cl.sendText(msg.to,"[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus)                        
               elif msg.to in periksa["gift2"]:
                      target = msg.contentMetadata["mid"]
                      lol = msg.to
                      msg.contentType = 9
                      msg.contentMetadata = { 'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                        'PRDTYPE':'THEME',
                                        'MSGTPL':'12'}
                      msg.to = target
                      msg.text == None
                      for zx in range(0,periksa['gift2jumlah']):

                        cl.sendMessage(msg)
                        k1.sendMessage(msg)
                        k2.sendMessage(msg)
                        k3.sendMessage(msg)
                        k4.sendMessage(msg)
                        k5.sendMessage(msg)						
                      del periksa["gift2"][lol]
                      try:
                            cl.sendText(lol,"Done 􀜁􀄯ok􏿿")
                      except:
                            pass
                      try:
                            k1.sendText(lol,"Done 􀜁􀄯ok􏿿")
                      except:
                            pass
                      try:
                            k2.sendText(lol,"Done 􀜁􀄯ok􏿿")
                      except:
                            pass
                      try:
                            k3.sendText(lol,"Done 􀜁􀄯ok􏿿")
                      except:
                            pass
                      try:
                            k4.sendText(lol,"Done 􀜁􀄯ok􏿿")
                      except:
                            pass
                      try:
                            k5.sendText(lol,"Done 􀜁􀄯ok􏿿")
                      except:
                            pass							
                        
            
                      with open('settingan.json', 'w') as fp:
                           json.dump(periksa, fp, sort_keys=True, indent=4)
                        
               elif msg.to in periksa["gift"]:
                        target = msg.contentMetadata["mid"]
                        lol = msg.to
                        msg.contentType = 9
                        msg.contentMetadata = { 'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                        'PRDTYPE':'THEME',
                                        'MSGTPL':'12'}
                        msg.to = target
                        msg.text == None
                        cl.sendMessage(msg)
                        k1.sendMessage(msg)
                        k2.sendMessage(msg)
                        k3.sendMessage(msg)
                        k4.sendMessage(msg)
                        k5.sendMessage(msg)
                        k6.sendMessage(msg)						
                        del periksa["gift"][lol]
                        try:
                            cl.sendText(lol,"Done 􀜁􀄯ok􏿿")
                        except:
                            pass
                        try:
                            k1.sendText(lol,"Done 􀜁􀄯ok􏿿")
                        except:
                            pass
                        try:
                            k2.sendText(lol,"Done 􀜁􀄯ok􏿿")
                        except:
                            pass
                        try:
                            k3.sendText(lol,"Done 􀜁􀄯ok􏿿")
                        except:
                            pass
                        try:
                            k4.sendText(lol,"Done 􀜁􀄯ok􏿿")
                        except:
                            pass
                        try:
                            k5.sendText(lol,"Done 􀜁􀄯ok􏿿")
                        except:
                            pass							
                        with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                   
               
            
            elif pesan is None:
                return
            if "myhelp" == pesan.lower():
                    cl.sendText(msg.to,helpMessage)
            if "key1" == pesan.lower():
                    cl.sendText(msg.to,helpMessage1)
            if "key2" == pesan.lower():
                    cl.sendText(msg.to,helpMessage2)                                        
            if "key3" == pesan.lower():
                    cl.sendText(msg.to,helpMessage3)
#            elif "liketype:" in pesan.lower():
#                xpesan = pesan.lower()
#                xres = xpesan.replace("liketype:","")
#                if xres == "":
#                    pass
#                else:
#                    number = int(xres)
#                    periksa['like'] = number
#                    with open('settingan.json', 'w') as fp:
#                        json.dump(periksa, fp, sort_keys=True, indent=4)
#                    cl.sendText(msg.to,"Like type set to %s"%(xres))
#            elif ".add " in pesan.lower():
#                xpesan = pesan.lower()
#               xres = xpesan.replace(".add ","")
#                if xres not in helpMessage:
#                  yres = xres.replace(xres[:1]+":","")
#                  abjadlist = yres.split(' ')
#                  periksa['emo'][xres[:1]] = abjadlist
#                  with open('settingan.json', 'w') as fp:
#                     json.dump(periksa, fp, sort_keys=True, indent=4)
#                  cl.sendText(msg.to,"emoji %s added to list"%(yres))
#            elif ".emo " in pesan.lower():
#                xpesan = pesan.lower()
#                emox = xpesan.replace(".emo ","")
#               if emox not in helpMessage:
#                 jmlh = len(emox)
#                  msk = int(0)
#                 mskx = int(0)
#                 listx = []
#                 lol = ""
#                  for x in range(jmlh):
#                     listx.append(emox[msk])
#                     msk += 1
#                  for x in listx:
#                    mskx += 1
#                     if x in periksa['emo']:
#                        lol += random.choice(periksa['emo'][x])
#                     else:
#                       lol =+ ' '
#                  cl.sendText(msg.to,"%s"%(lol))
            elif "Youtubesearch: " in msg.text:
                    query = msg.text.replace("Youtube ","")
                    with requests.session() as s:
                        s.headers['user-agent'] = 'Mozilla/5.0'
                        url = 'http://www.youtube.com/results'
                        params = {'search_query': query}
                        r = s.get(url, params=params)
                        soup = BeautifulSoup(r.content, 'html.parser')
                        hasil = ""
                        for a in soup.select('.yt-lockup-title > a[title]'):
                            if '&list=' not in a['href']:
                                hasil += ''.join((a['title'],'\nUrl : http://www.youtube.com' + a['href'],'\n\n'))
                        cl.sendText(msg.to,hasil)
                        #print '[Command] Youtube Search'
            elif "music " in pesan.lower():
                xpesan = pesan.lower()
                songname = xpesan.replace("music ","")
                params = {'songname':songname}
                r=requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?'+urllib.parse.urlencode(params))
                data = r.text
                data=json.loads(data)
                
                for song in data:
                    cl.sendText(msg.to,"Music\n\n%s (%s)\nDownload: %s"%(song[0],song[1],song[4]))
                    cl.sendAudioWithURL(msg.to,song[4])					
            elif "lirik " in pesan.lower():
                xpesan = pesan.lower()
                songname = xpesan.replace("lirik ","")
                params = {'songname':songname}
                r=requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?'+urllib.parse.urlencode(params))
                data = r.text
                data=json.loads(data)
                for song in data:
                    cl.sendText(msg.to,"%s \n\n %s"%(song[0],song[5]))
            elif "Spam " in pesan:
                   txt = pesan.split(" ")
                   jmlh = int(txt[2])
                   teks = msg.text.replace("Spam "+str(txt[1])+" "+str(jmlh)+ " ","")
                   tulisan = jmlh * (teks+"\n")
                  #Haku sholeh <3
                   if txt[1] == "on":
                        if jmlh <= 10000:
                             for x in range(jmlh):
                                   cl.sendText(msg.to, teks)
                        else:
                               cl.sendText(msg.to, "ARE YOU FUCKING KIDDING ME? ")
                   elif txt[1] == "off":
                         if jmlh <= 10000:
                               cl.sendText(msg.to, tulisan)
                         else:
                               cl.sendText(msg.to, "ARE YOU FUCKING KIDDING ME? ")
            elif msg.text.lower() == 'bot cancel':
                if msg.toType == 2:
                    G = cl.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        random.choice(KAC).cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            random.choice(KAC).sendText(msg.to,"No one is inviting")
                        else:
                            random.choice(KAC).sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"Can not be used outside the group")
                    else:
                        random.choice(KAC).sendText(msg.to,"Not for use less than group")
            elif "autojoin:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autojoin:","")
                if xres == "off":
                    periksa['autojoin'] = "off"
                    cl.sendText(msg.to,"Auto Join Set to OFF")
                elif xres == "on":
                    periksa['autojoin'] = "all"
                    cl.sendText(msg.to,"Auto Join Set to All")
                elif xres == "wl":
                    periksa['autojoin'] = "wl"
                    cl.sendText(msg.to,"Auto Join Set to Wl")
            elif "autolike:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autolike:","")
                if xres == "off":
                    periksa['autolike'] = False
                    cl.sendText(msg.to,"Auto Like already Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['autolike'] = True
                    cl.sendText(msg.to,"Auto Like already On 􀜁􀄯ok􏿿")
            elif "autoadd:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autoadd:","")
                if xres == "off":
                    periksa['autoadd'] = False
                    cl.sendText(msg.to,"Auto Add already Off")
                elif xres == "on":
                    periksa['autoadd'] = True
                    cl.sendText(msg.to,"Auto Add already On")
            elif "autopurge:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autopurge:","")
                if xres == "off":
                    del periksa['autopurge'][msg.to]
                    cl.sendText(msg.to,"Auto Purge already Off")
                elif xres == "on":
                    periksa['autopurge'][msg.to] = True
                    cl.sendText(msg.to,"Auto Purge already On")
            elif "mimic:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("mimic:","")
                if xres == "off":
                    periksa['mimic'] = False
                    cl.sendText(msg.to,"Mimic alread Off")
                elif xres == "on":
                    periksa['mimic'] = True
                    cl.sendText(msg.to,"Mimic already On")
            elif "pjoin:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("pjoin:","")
                if xres == "off":
                    del periksa['pjoin'][msg.to]
                    cl.sendText(msg.to,"Protect join is off")
                elif xres == "on":
                    periksa['pjoin'][msg.to] = True
                    cl.sendText(msg.to,"Protect join is on")                    
            elif "block qr:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("block qr:","")
                if xres == "off":
                    del periksa['lockqr'][msg.to]
                    cl.sendText(msg.to,"QR already Off")
                elif xres == "on":
                    periksa['lockqr'][msg.to] = True
                    cl.sendText(msg.to,"QR already On")
            elif pesan in ["Namelock:on"]:
                if msg.to in periksa['gname']:
                    periksa['gname'][msg.to] = True
                    periksa['proname'][msg.to] = cl.getGroup(msg.to).name
                    cl.sendText(msg.to,"NameLock Enabled")
                else:
                    cl.sendText(msg.to,"NameLock Alredy On")
                    periksa['gname'][msg.to] = True
                    periksa['proname'][msg.to] = cl.getGroup(msg.to).name
            elif pesan in ["Namelock:off"]:
                if msg.to in periksa['gname']:
                    cl.sendText(msg.to,"NameLock Disable")
                    del periksa['gname'][msg.to]
                else:
                    del periksa['gname'][msg.to]
                    cl.sendText(msg.to,"NameLock Alredy Off")
            elif pesan in ['Iconlock:on']:
                if msg.to in periksa["picon"]:
                    cl.sendText(msg.to,"PictureProtect Already on")
                    periksa["picon"][msg.to] = True
                else:
                    periksa["picon"][msg.to] = True
                    cl.sendText(msg.to,"PictureProtect Enabled")
            elif pesan in ['Iconlock:off']:
                if msg.to in periksa["picon"]:
                    cl.sendText(msg.to,"PictureProtect Already off")
                    del periksa["picon"][msg.to]
                else:
                    del periksa["picon"][msg.to]
                    cl.sendText(msg.to,"PictureProtect Dissabled")                     
            elif "linkprotect:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("linkprotect:","")
                if xres == "off":
                    del periksa['linkpro'][msg.to]
                    cl.sendText(msg.to,"Siri already Off")
                elif xres == "on":
                    periksa['linkpro'][msg.to] = True
                    cl.sendText(msg.to,"Siri already On")                    
            elif "blockinvite:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("blockinvite:","")
                if xres == "off":
                    del periksa['autocancel'][msg.to]
                    cl.sendText(msg.to,"Block invitation Off")
                elif xres == "on":
                    periksa['autocancel'][msg.to] = True
                    cl.sendText(msg.to,"Block invitation On")
            elif "protectmax:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("protectmax:","")
                if xres == "off":
                    del periksa['protect'][msg.to]
                    del periksa['lockqr'][msg.to]
                    del periksa['gname'][msg.to]
                    del periksa['picon'][msg.to] 
                    del periksa['pjoin'][msg.to]                                                            
                    del periksa['linkpro'][msg.to]                    
                    del periksa['autopurge'][msg.to]
                    del periksa['autocancel'][msg.to]
                    cl.sendText(msg.to,"Protection already Off 􀜁􀄰no􏿿")
                elif xres == "on":
                    periksa['protect'][msg.to] = True
                    periksa['autocancel'][msg.to] = True
                    periksa['lockqr'][msg.to] = True
                    periksa['gname'][msg.to] = True
                    periksa['picon'][msg.to] = True 
                    periksa['pjoin'][msg.to] = True                                                            
                    periksa['linkpro'][msg.to] = True                    
                    periksa['autopurge'][msg.to] = True
                    cl.sendText(msg.to,"Protection already On 􀜁􀄯ok􏿿")
            elif "myset" in pesan.lower():
                if msg.to in periksa['protect']:
                    protect = "on √"
                else:
                    protect = "off ×"
                if msg.to in periksa['autopurge']:
                    autopurge = "on √"
                else:
                    autopurge = "off ×"
                if msg.to in periksa['lockqr']:
                    lockqr = "on √"
                else:
                    lockqr = "off ×"
                if msg.to in periksa['gname']:
                    gname = "on √"
                else:
                    gname = "off ×"
                if msg.to in periksa['picon']:
                    picon = "on √"
                else:
                    picon = "off ×"
                if msg.to in periksa['pjoin']:
                    pjoin = "on √"
                else:
                    pjoin = "off ×"                                                              
                if msg.to in periksa['linkpro']:
                    linkpro = "on √"
                else:
                    linkpro = "off ×"                    
                if msg.to in periksa['autocancel']:
                    autocancel = "on √"
                else:
                    autocancel = "off ×"
                if periksa['autolike'] == True:
                    autolike = "on √"
                else:
                     autolike = "off ×"
                if periksa['autoadd'] == True:
                    autoadd = "on √"
                else:
                     autoadd = "off ×"
                if periksa['autorejc'] == True:
                    autorejc = "on √"
                else:
                     autorejc = "off ×"
                if periksa['autojoin'] == "all":
                    autojoin = "All √"
                elif periksa['autojoin'] == "wl":
                     autojoin = "Wl √"
                else:
                    autojoin = "off ×"
                cl.sendText(msg.to,"╔════════════════\n╠ ⊰♜⊱ SETTINGS  ♜\n╠\n╠ • Protectmax: %s\n╠ • Blockinvite: %s\n╠ • Autopurge: %s\n╠ • Block qr: %s\n╠ • Namelock: %s\n╠ • Iconlock: %s\n╠ • Pjoin: %s\n╠ • linkprotect:⊰ %s\n╠ • Autolike: %s\n╠ • Autoadd: %s\n╠ • Autoreject: %s\n╠ • Autojoin: %s\n╠ \n╠ ♨Dansus69 team bot♨\n╚════════════════"%(protect,autocancel,autopurge,lockqr,gname,picon,pjoin,linkpro,autolike,autoadd,autorejc,autojoin)) 
            elif "addmimic @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    G = cl.getGroupIdsJoined()
                    cgroup = cl.getGroups(G)
                    ngroup = ""
                    for mention in mentionees:
                        periksa['tmimic'][mention['M']] = True
                        cl.sendText(msg.to,"Added 􀜁􀄯ok􏿿")
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
            elif "unmimic @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    G = cl.getGroupIdsJoined()
                    cgroup = cl.getGroups(G)
                    ngroup = ""
                    for mention in mentionees:
                        del periksa['tmimic'][mention['M']]
                        cl.sendText(msg.to,"Target Mimic has been Removed")
                        with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
            elif "autoreject:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("autoreject:","")
                if xres == "off":
                    periksa['autorejc'] = False
                    cl.sendText(msg.to,"Auto Reject already Off")
                elif xres == "on":
                    periksa['autorejc'] = True
                    cl.sendText(msg.to,"Auto Reject already On")
            elif "rgroups" in pesan.lower():
                g1 = cl.getGroupIdsInvited()
                g2 = k1.getGroupIdsInvited()
                g3 = k2.getGroupIdsInvited()
                g4 = k3.getGroupIdsInvited()
                g5 = k4.getGroupIdsInvited()
                g6 = k5.getGroupIdsInvited()
                g2 = k6.getGroupIdsInvited()
                g3 = k7.getGroupIdsInvited()
                g4 = k8.getGroupIdsInvited()
                g5 = k9.getGroupIdsInvited()
                g6 = k10.getGroupIdsInvited()				
                for x in g1:
                    cl.rejectGroupInvitation(x)
                pass
                cl.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                for x in g2:
                    k1.rejectGroupInvitation(x)
                pass
                k1.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                for x in g3:
                    k2.rejectGroupInvitation(x)
                pass
                k2.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                for x in g4:
                    k3.rejectGroupInvitation(x)
                pass
                k3.sendText(msg.to,"Done 􀜁􀄯ok􏿿")	
                for x in g5:
                    k4.rejectGroupInvitation(x)
                pass
                k4.sendText(msg.to,"Done 􀜁􀄯ok􏿿")	
                for x in g6:
                    k5.rejectGroupInvitation(x)
                pass
                k5.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                    k6.rejectGroupInvitation(x)
                pass
                k6.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                for x in g3:
                    k7.rejectGroupInvitation(x)
                pass
                k7.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                for x in g4:
                    k8.rejectGroupInvitation(x)
                pass
                k8.sendText(msg.to,"Done 􀜁􀄯ok􏿿")	
                for x in g5:
                    k9.rejectGroupInvitation(x)
                pass
                k9.sendText(msg.to,"Done 􀜁􀄯ok􏿿")	
                for x in g6:
                    k10.rejectGroupInvitation(x)
                pass
                k10.sendText(msg.to,"Done 􀜁􀄯ok􏿿")						
            elif "set on" == pesan.lower():
                if msg.to in sider['readPoint']:
                    try:
                        del sider['readPoint'][msg.to]
                        del sider['readMember'][msg.to]
                        del sider['setTime'][msg.to]
                    except:
                        pass
                    sider['readPoint'][msg.to] = msg.id
                    sider['readMember'][msg.to] = ""
                    sider['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                    sider['ROM'][msg.to] = {}
                    with open('sider.json', 'w') as fp:
                      json.dump(sider, fp, sort_keys=True, indent=4)
                    cl.sendText(msg.to,"Set already on 􀜁􀄯ok􏿿")
                else:
                    try:
                        del sider['readPoint'][msg.to]
                        del sider['readMember'][msg.to]
                        del sider['setTime'][msg.to]
                    except:
                        pass
                    sider['readPoint'][msg.to] = msg.id
                    sider['readMember'][msg.to] = ""
                    sider['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                    sider['ROM'][msg.to] = {}
                    with open('sider.json', 'w') as fp:
                       json.dump(sider, fp, sort_keys=True, indent=4)
                    cl.sendText(msg.to,"Set On 􀜁􀄯ok􏿿")
                    #print sider
            elif "set off" == pesan.lower():
                if msg.to not in sider['readPoint']:
                    cl.sendText(msg.to,"Set already Off 􀜁􀄰no􏿿")
                else:
                    try:
                       del sider['readPoint'][msg.to]
                       del sider['readMember'][msg.to]
                       del sider['setTime'][msg.to]
                    except:
                       pass
                    cl.sendText(msg.to,"Set already Off 􀜁􀄰no􏿿")
            elif "view" == pesan.lower():
                    if msg.to in sider['readPoint']:
                        if sider["ROM"][msg.to].items() == []:
                             cl.sendText(msg.to, "Result:\nNone")
                        else:
                            chiya = []
                            for rom in sider["ROM"][msg.to].items():
                                chiya.append(rom[1])                                
                            cmem = cl.getContacts(chiya)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = 'Result:\n'
                            for x in range(len(cmem)):
                                xname = str(cmem[x].displayName)
                                pesan = ''
                                pesan2 = pesan+"@a\n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                                zx2.append(zx)
                                zxc += pesan2
                            msg.contentType = 0         
                            print (zxc)
                            msg.text = xpesan+ zxc + "\nCheck time: %s\nNow time: %s"%(sider['setTime'][msg.to],datetime.now().strftime('%H:%M:%S'))
                            lol ={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                            print (lol)
                            msg.contentMetadata = lol
                            try:
                              cl.sendMessage(msg)
                            except Exception as error:
                                  print (error)
                            pass
                          
                    else:
                        cl.sendText(msg.to, "Set not on 􀜁􀄰no􏿿")
#---------------------------------------------- RG

#-------------------------------------------------- RG                                            
            elif msg.text.lower() == 'mygroups':
                    G = cl.getGroupIdsJoined()
                    cgroup = cl.getGroups(G)
                    ngroup = ""
                    for x in range(len(cgroup)):
                       ngroup += "\n["+ str(x) +"] " + cgroup[x].name + " | Members: " + str(len(cgroup[x].members))
                    pass
                    cl.sendText(msg.to,"List Groups:\n%s\n\nTotal Groups: %s"%(ngroup,str(len(cgroup))))
            elif "mc: " in pesan.lower():
                   umid = pesan.replace('mc: ','')
                   msg.contentType = 13
                   msg.text = None
                   msg.contentMetadata = {'mid': umid}
                   cl.sendMessage(msg)
#            elif "cari @" in pesan.lower():
#                   if 'MENTION' in msg.contentMetadata.keys() != None:
#                    names = re.findall(r'@(\w+)', msg.text)
#                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
#                    mentionees = mention['MENTIONEES']
#                    G = cl.getGroupIdsJoined()
#                    cgroup = cl.getGroups(G)
#                    ngroup = ""
#                    for mention in mentionees:
#                      for x in range(len(cgroup)):
#                        gMembMids = [contact.mid for contact in cgroup[x].members]
#                        if mention['M'] in gMembMids:
#                            ngroup += "\n" + cgroup[x].name + " | Members: " + str(len(cgroup[x].members))    
#                    if ngroup == "":
#                          cl.sendText(msg.to, "Tidak ditemukan")
#                    else:
#                        cl.sendText(msg.to,"Ada di Group:\n%s\n"%(ngroup))
            elif msg.text.lower() == 'link on':
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    gurl = cl.reissueGroupTicket(msg.to)
                    cl.sendText(msg.to,"http://line.me/R/ti/g/"+gurl)
                else:
                    pass
            elif "Gn: " in pesan:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Gn: ","")
                    cl.updateGroup(X)
                else:
                    cl.sendText(msg.to,"It can't be used besides the group.")
            elif msg.text.lower() == 'link off':
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    cl.sendText(msg.to,"QR already Off 􀜁􀄯ok􏿿")
                else:
                    pass
            elif "allmid" == pesan.lower():
                cl.sendText(msg.to,msg.to)
            elif pesan.lower() in ["mid"]:
                cl.sendText(msg.to,msg.from_)
            elif msg.text.lower() == 'k1 mid':
                k1.sendText(msg.to,k1mid)
            elif msg.text.lower() == 'k2 mid':
                k2.sendText(msg.to,k2mid)
            elif msg.text.lower() == 'k3 mid':
                k3.sendText(msg.to,k3mid)
            elif msg.text.lower() == 'k4 mid':
                k4.sendText(msg.to,k4mid)
            elif msg.text.lower() == 'k5 mid':
                k5.sendText(msg.to,k5mid)
            elif msg.text.lower() == 'k1 mid':
                k6.sendText(msg.to,k1mid)
            elif msg.text.lower() == 'k2 mid':
                k7.sendText(msg.to,k2mid)
            elif msg.text.lower() == 'k3 mid':
                k8.sendText(msg.to,k3mid)
            elif msg.text.lower() == 'k4 mid':
                k9.sendText(msg.to,k4mid)
            elif msg.text.lower() == 'k5 mid':
                k10.sendText(msg.to,k5mid)                           
            elif msg.text.lower() == 'allmid':
                cl.sendText(msg.to,mid)
                k1.sendText(msg.to,k1mid)
                k2.sendText(msg.to,k2mid)
                k3.sendText(msg.to,k3mid)
                k4.sendText(msg.to,k4mid)
                k5.sendText(msg.to,k1mid)
                k6.sendText(msg.to,k1mid)
                k7.sendText(msg.to,k2mid)
                k8.sendText(msg.to,k3mid)
                k9.sendText(msg.to,k4mid)
                k10.sendText(msg.to,k1mid)                                
            elif pesan.lower() in ["sp"]:
                start = time.time()
                cl.sendText(msg.to, "Loading ...")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%s sec" % (elapsed_time))
            elif pesan.lower() in ["speed"]:
                start = time.time()
                cl.sendText(msg.to, "Loading ...")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%s sec" % (elapsed_time))				
            elif msg.text in ["Bro"]:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        k2.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        k3.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        k4.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        k5.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        k6.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        k7.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        k8.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        k4
k9.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        k10.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.01)
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        k10.updateGroup(G)
                        k1.sendText(msg.to,"hallu..")
                        k2.sendText(msg.to,"assallamualaikum")
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G) 
            elif msg.text.lower() == 'k1 join':
                     G = cl.getGroup(msg.to)
                     G.preventJoinByTicket = False
                     cl.updateGroup(G)
                     Ti = cl.reissueGroupTicket(msg.to)
                     k1.acceptGroupInvitationByTicket(msg.to,Ti)					 
                     X = k1.getGroup(msg.to)
                     X.preventJoinByTicket = True
                     k1.updateGroup(X)
            elif msg.text.lower() == 'k2 join':
                     G = cl.getGroup(msg.to)
                     G.preventJoinByTicket = False
                     cl.updateGroup(G)
                     Ti = cl.reissueGroupTicket(msg.to)
                     k2.acceptGroupInvitationByTicket(msg.to,Ti)					 
                     X = k2.getGroup(msg.to)
                     X.preventJoinByTicket = True
                     k2.updateGroup(X)
            elif msg.text.lower() == 'k3 join':
                     G = cl.getGroup(msg.to)
                     G.preventJoinByTicket = False
                     cl.updateGroup(G)
                     Ti = cl.reissueGroupTicket(msg.to)
                     k3.acceptGroupInvitationByTicket(msg.to,Ti)					 
                     X = k3.getGroup(msg.to)
                     X.preventJoinByTicket = True
                     k3.updateGroup(X)
            elif msg.text.lower() == 'k4 join':
                     G = cl.getGroup(msg.to)
                     G.preventJoinByTicket = False
                     cl.updateGroup(G)
                     Ti = cl.reissueGroupTicket(msg.to)
                     k4.acceptGroupInvitationByTicket(msg.to,Ti)					 
                     X = k4.getGroup(msg.to)
                     X.preventJoinByTicket = True
                     k4.updateGroup(X)
            elif msg.text.lower() == 'k5 join':
                     G = cl.getGroup(msg.to)
                     G.preventJoinByTicket = False
                     cl.updateGroup(G)
                     Ti = cl.reissueGroupTicket(msg.to)
                     k5.acceptGroupInvitationByTicket(msg.to,Ti)					 
                     X = k5.getGroup(msg.to)
                     X.preventJoinByTicket = True
                     k5.updateGroup(X)                     
            elif msg.text.lower() == 'siri join':
                     G = cl.getGroup(msg.to)
                     G.preventJoinByTicket = False
                     cl.updateGroup(G)
                     Ti = cl.reissueGroupTicket(msg.to)
                     k6.acceptGroupInvitationByTicket(msg.to,Ti)					 
                     X = k6.getGroup(msg.to)
                     X.preventJoinByTicket = True
                     k6.updateGroup(X)					 
            elif msg.text.lower() == 'bye':
                k1.leaveGroup(msg.to)
                k2.leaveGroup(msg.to)
                k3.leaveGroup(msg.to)
                k4.leaveGroup(msg.to)
                k5.leaveGroup(msg.to)
                k6.leaveGroup(msg.to)
                k7.leaveGroup(msg.to)
                k8.leaveGroup(msg.to)
                k9.leaveGroup(msg.to)
                k10.leaveGroup(msg.to)
            elif msg.text.lower() == '@papay':
                cl.leaveGroup(msg.to)				
            elif msg.text.lower() == 'k1 @bye':
                k1.leaveGroup(msg.to)
            elif msg.text.lower() == 'k2 @bye':
                k2.leaveGroup(msg.to)
            elif msg.text.lower() == 'k3 @bye':
                k3.leaveGroup(msg.to)
            elif msg.text.lower() == 'k4 @bye':
                k4.leaveGroup(msg.to)
            elif msg.text.lower() == 'k5 @bye':
                k5.leaveGroup(msg.to)
            elif msg.text.lower() == 'siri @bye':
                k6.leaveGroup(msg.to)
            elif "staffadd:on" == pesan.lower():
                periksa["addwl"][msg.to] = True
                cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")
            elif "staffadd:off" == pesan.lower():
                del periksa["addwl"][msg.to]
                cl.sendText(msg.to,"Already Off 􀜁􀄯ok􏿿")
            elif "expelstaff:on" == pesan.lower():
                periksa["delwl"][msg.to] = True
                cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")
            elif "expelstaff:off" == pesan.lower():
                del periksa["delwl"][msg.to]
                cl.sendText(msg.to,"Already Off 􀜁􀄯ok􏿿")
            elif "join " == pesan:
                 xlink = msg.text.replace("join ","")
                 ticket = xlink.split("/ti/g/")
                 try:
                   group = cl.findGroupByTicket(ticket[1])
                   cl.acceptGroupInvitationByTicket(group.id,ticket[1])
                   k1.acceptGroupInvitationByTicket(group.id,ticket[1])
                   k2.acceptGroupInvitationByTicket(group.id,ticket[1])
                   k3.acceptGroupInvitationByTicket(group.id,ticket[1])
                   k4.acceptGroupInvitationByTicket(group.id,ticket[1])
                   k5.acceptGroupInvitationByTicket(group.id,ticket[1])				   
                   cl.sendText(msg.to,"Joined to %s"%(group.name))
                   k1.sendText(msg.to,"Joined to %s"%(group.name))
                   k2.sendText(msg.to,"Joined to %s"%(group.name))
                   k3.sendText(msg.to,"Joined to %s"%(group.name))
                   k4.sendText(msg.to,"Joined to %s"%(group.name))
                   k5.sendText(msg.to,"Joined to %s"%(group.name))
                 except:
                     pass
            elif "gift:on" == pesan.lower():
                periksa["gift"][msg.to] = True
                cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")				  
            elif "ban:on" == pesan.lower():
                periksa["addbanmode"][msg.to] = True
                cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")
            elif "ban:off" == pesan.lower():
                del periksa["addbanmode"][msg.to]
                cl.sendText(msg.to,"Already Off 􀜁􀄯ok􏿿")
            elif "target:on" == pesan.lower():
                periksa["addtarget"][msg.to] = True
                cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")
            elif "target:off" == pesan.lower():
                del periksa["addtarget"][msg.to]
                cl.sendText(msg.to,"Already Off 􀜁􀄯ok􏿿")
            elif "untarget:on" == pesan.lower():
                periksa["deltarget"][msg.to] = True
                cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")
            elif "untarget:off" == pesan.lower():
                del periksa["deltarget"][msg.to]
                cl.sendText(msg.to,"Already Off 􀜁􀄯ok􏿿")
            elif "unban:on" == pesan.lower():
                periksa["delbanmode"][msg.to] = True
                cl.sendText(msg.to,"Send contact 􀜁􀅪Doctor􏿿")
            elif "unban:off" == pesan.lower():
                del periksa["delbanmode"][msg.to]
                cl.sendText(msg.to,"Already Off 􀜁􀄯ok􏿿")
            elif "staffadd @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["wl"]:
                            cl.sendText(msg.to,"Contact already in list")
                        else:
                            periksa["wl"][mention['M']] = True
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Added 􀜁􀄯ok􏿿")
            elif "expelstaff @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["wl"]:
                            del periksa["wl"][mention['M']]
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        else:
                            cl.sendText(msg.to,"Contact not in list")
            elif "bannet @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["banlist"]:
                            cl.sendText(msg.to,"Already banlist")
                        elif mention['M'] in Bots or mention['M'] in periksa["wl"]:
                            cl.sendText(msg.to,"Can't banned staff")
                        else:
                            periksa["banlist"][mention['M']] = True
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Added to banned")
            elif "unban @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["banlist"]:
                            del periksa["banlist"][mention['M']]
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        else:
                            cl.sendText(msg.to,"Contact not in list")
            elif "addtarget @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["target"]:
                            cl.sendText(msg.to,"Contact already in list")
                        elif mention['M'] in Bots or mention['M'] in periksa["wl"]:
                            cl.sendText(msg.to,"Can't add wl to target")
                        else:
                            periksa["target"][mention['M']] = True
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Added 􀜁􀄯ok􏿿")
							
            elif "untarget @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in periksa["target"]:
                            del periksa["target"][mention['M']]
                            with open('settingan.json', 'w') as fp:
                                json.dump(periksa, fp, sort_keys=True, indent=4)
                            cl.sendText(msg.to,"Deleted 􀜁􀄯ok􏿿")
                        else:
                            cl.sendText(msg.to,"Contact not in list")
            elif "listtarget" == pesan.lower():
                if periksa["target"] == {}:
                    cl.sendText(msg.to,"Nothing 􀜁􀄶Not Bad􏿿")
                else:
                    mc = []
                    for mi_d in periksa["target"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n* ".join(str(i) for i in nban)
                    cl.sendText(msg.to," √ List target ⊰ \n\n* %s\n\nTotal Target: %s"%(jo,str(len(cban))))
            elif "banlist" == pesan.lower():
                if periksa["banlist"] == {}:
                    cl.sendText(msg.to,"Nothing 􀜁􀄶Not Bad􏿿")
                else:
                    mc = []
                    for mi_d in periksa["banlist"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n•⊰ ".join(str(i) for i in nban)
                    cl.sendText(msg.to," √List Banned  ⊰\n\n•⊰ %s\n\nTotal Banlist: %s"%(jo,str(len(cban))))
#            elif "cek ban" == pesan.lower():
#                if msg.toType == 2:
#                    group = cl.getGroup(msg.to)
#                    gMembMids = [contact.mid for contact in group.members]
#                    matched_list = []
#                    for tag in periksa["banlist"]:
#                        matched_list+=filter(lambda str: str == tag, gMembMids)
#                    cocoa = []
#                    for mm in matched_list:
#                        cocoa.append(mm)
#                    pass
#                    cban = cl.getContacts(cocoa)
#                    nban = []
#                    for x in range(len(cban)):
#                        nban.append(cban[x].displayName)
#                   pass
#                   jo = "\n☠ ".join(str(i) for i in nban)
#                   if cocoa != []:
#                        cl.sendText(msg.to,"☠ List Banned dalam Group ini ☠ \n☠ %s\n\nTotal Banlist: %s"%(jo,str(len(cban))))
#                    else:
#                        cl.sendText(msg.to,"Tidak ada")
            elif "stafflist" == pesan.lower():
                if periksa["wl"] == {}:
                    cl.sendText(msg.to,"Nothing 􀜁􀄶Not Bad􏿿")
                else:
                    mc = []
                    for mi_d in periksa["wl"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n•⊰ ".join(str(i) for i in nban)
                    cl.sendText(msg.to," √ Stafflist ⊰ \n\n•⊰ %s\n\nTotal Staff: %s"%(jo,str(len(cban))))
            elif "mimiclist" == pesan.lower():
                if periksa["tmimic"] == {}:
                    cl.sendText(msg.to,"Nothing 􀜁􀄶Not Bad􏿿")
                else:
                    mc = []
                    for mi_d in periksa["tmimic"]:
                        mc.append(mi_d)
                    pass
                    cban = cl.getContacts(mc)
                    nban = []
                    for x in range(len(cban)):
                        nban.append(cban[x].displayName)
                    pass
                    jo = "\n•⊰ ".join(str(i) for i in nban)
                    cl.sendText(msg.to," √ List mimic: ⊰\n\n•⊰ %s\n\nTotal: %s"%(jo,str(len(cban))))
            elif pesan.lower() in ["me"]:
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': msg.from_}
                      cl.sendMessage(msg)
            elif pesan.lower() in ["allbots"]:
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k1mid}					  
                      k1.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k2mid}
                      k2.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k3mid}
                      k3.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k4mid}
                      k4.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k5mid}
                      k5.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k6mid}					  
                      k6.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k7mid}
                      k7.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k8mid}
                      k8.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k9mid}
                      k9.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k10mid}
                      k10.sendMessage(msg)
            elif pesan.lower() in ["mybots"]:
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k1mid}					  
                      cl.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k2mid}
                      cl.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k3mid}
                      cl.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k4mid}
                      cl.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k5mid}
                      cl.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k6mid}
                      cl.sendMessage(msg)  
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k7mid}
                      cl.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k8mid}
                      cl.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k9mid}
                      cl.sendMessage(msg)
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': k10mid}
                      cl.sendMessage(msg)
				  
            elif msg.text.lower() == 'cancel':
                if msg.toType == 2:
                    G = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in G.invitee]
                    for _mid in gMembMids:
                        cl.cancelGroupInvitation(msg.to,[_mid])
                    cl.sendText(msg.to,"Done")
#--------------------------------------------KICK ------------ RG                        
            elif "kick " in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            kicker=random.choice(KAC)
                            kicker.kickoutFromGroup(msg.to, [mention['M']])							
                        except:
                            try:
                                kicker=random.choice(KAC)
                                kicker.kickoutFromGroup(msg.to, [mention['M']])								
                            except:
                                cl.kickoutFromGroup(msg.to, [mention['M']])						
						
            elif "vkick " in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            kicker=random.choice(KAC)						
                            kicker.findAndAddContactsByMid(mention['M'])
                            kicker.kickoutFromGroup(msg.to, [mention['M']])
                            kicker.inviteIntoGroup(msg.to, [mention['M']])
                            kicker.cancelGroupInvitation(msg.to, [mention['M']])
                            kicker.inviteIntoGroup(msg.to, [mention['M']])
                            kicker.cancelGroupInvitation(msg.to, [mention['M']])							
                        except Exception as error:
                            print (error)
                            try:
                                kicker=random.choice(KAC)							
                                kicker.findAndAddContactsByMid(mention['M'])
                                kicker.kickoutFromGroup(msg.to, [mention['M']])
                                kicker.inviteIntoGroup(msg.to, mention['M'])
                                kicker.cancelGroupInvitation(msg.to, [mention['M']])
                                kicker.inviteIntoGroup(msg.to, mention['M'])
                                kicker.cancelGroupInvitation(msg.to, [mention['M']])								
                            except:
                                cl.findAndAddContactsByMid(mention['M'])
                                cl.kickoutFromGroup(msg.to, mention['M'])
                                cl.inviteIntoGroup(msg.to, [mention['M']])
                                cl.cancelGroupInvitation(msg.to, [mention['M']])
                                cl.inviteIntoGroup(msg.to, [mention['M']])
                                cl.cancelGroupInvitation(msg.to, [mention['M']])								
            
                                
            elif "boom" == pesan.lower():
                if msg.toType == 2:
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if g.mid not in Bots:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Target not found")
                    else:
                        for target in targets:
                            try:
                                klist=[k1,k2,k3,k4]
                                kicker=random.choice(klist)
                                kicker.kickoutFromGroup(msg.to,[target])
                            except:
                                pass
            elif "Mayhem" in msg.text:
                if msg.toType == 2:
                    _name = msg.text.replace("Mayhem","")
                    gs = k1.getGroup(msg.to)
                    gs = k2.getGroup(msg.to)
                    gs = k3.getGroup(msg.to)
                    gs = k4.getGroup(msg.to)
                    gs = k5.getGroup(msg.to)
                    gs = k6.getGroup(msg.to)
                    gs = k7.getGroup(msg.to)
                    gs = k8.getGroup(msg.to)
                    gs = k9.getGroup(msg.to)
                    gs = k10.getGroup(msg.to)                                                                                                    
                    k1.sendText(msg.to,"「 Mayhem 」\nMayhem is STARTING♪\n ' abort' to abort♪") 
                    k2.sendText(msg.to,"「 Mayhem 」\n 46 victims shall yell hul·la·ba·loo♪\n /ˌhələbəˈlo͞o,ˈhələbəˌlo͞o/")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        kd.sendText(msg.to,"Tidak ditemukan")
                    else:
                        for target in targets:
                            if not target in Bots:
                                try:
                                   klist=[k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                                   kicker=random.choice(klist)
                                   kicker.kickoutFromGroup(msg.to,[target])
                                   print (msg.to,[g.mid])
                                except:
                                   k1.sendText(msg.to,"Mayhem done")

#------------------------------------------------- RG                                                                                                                           
            elif "change pict" == pesan.lower():
                periksa['cpp11'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendText(msg.to,"Send your image")
            elif "k1 changepict" == pesan.lower():
                periksa['cpp1'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                k1.sendText(msg.to,"Send your image")
            elif "k2 changepict" == pesan.lower():
                periksa['cpp2'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                k2.sendText(msg.to,"Send your image")
            elif "k3 changepict" == pesan.lower():
                periksa['cpp3'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                k3.sendText(msg.to,"Send your image")
            elif "k4 changepict" == pesan.lower():
                periksa['cpp4'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                k4.sendText(msg.to,"Send your image")
            elif "k5 changepict" == pesan.lower():
                periksa['cpp5'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                k5.sendText(msg.to,"Send your image")
            elif "all changepict" == pesan.lower():
                periksa['cpp1'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                             json.dump(periksa, fp, sort_keys=True, indent=4)
                k1.sendText(msg.to,"Send your image")
                periksa['cpp2'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                k2.sendText(msg.to,"Send your image")
                periksa['cpp3'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                k3.sendText(msg.to,"Send your image")
                periksa['cpp4'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                k4.sendText(msg.to,"Send your image")
                periksa['cpp5'][msg.to] = True
                with open('settingan.json', 'w') as fp:
                        json.dump(periksa, fp, sort_keys=True, indent=4)
                k5.sendText(msg.to,"Send your image")                
            elif "killban" == pesan.lower():
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in periksa["banlist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendText(msg.to,"Nothing banned user")
                        return
                    for jj in matched_list:
                      try:
k2.kickoutFromGroup(msg.to,[jj])
                        k3.kickoutFromGroup(msg.to,[jj])
                        k4.kickoutFromGroup(msg.to,[jj])
                        k5.kickoutFromGroup(msg.to,[jj])
                        k6.kickoutFromGroup(msg.to,[jj])
                        k7.kickoutFromGroup(msg.to,[jj])
                        k8.kickoutFromGroup(msg.to,[jj])
                        k9.kickoutFromGroup(msg.to,[jj])
                        k10.kickoutFromGroup(msg.to,[jj])
                        k1.kickoutFromGroup(msg.to,[jj])						
                      except:
                        cl.kickoutFromGroup(msg.to,[jj])
                    k1.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
            elif "clearban" in pesan.lower():
                periksa['banlist'] = {}
                with open('settingan.json', 'w') as fp:
                    json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
            elif "cleartarget" in pesan.lower():
                periksa['target'] = {}
                with open('settingan.json', 'w') as fp:
                    json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
            elif "clearstaff" in pesan.lower():
                periksa['wl'] = {}
                with open('settingan.json', 'w') as fp:
                    json.dump(periksa, fp, sort_keys=True, indent=4)
                cl.sendText(msg.to,"Done")
            elif msg.text.lower() == 'gc':
                try:
                    group = cl.getGroup(msg.to)
                    GS = group.creator.mid
                    M = Message()
                    M.to = msg.to
                    M.contentType = 13
                    M.contentMetadata = {'mid': GS}
                    cl.sendMessage(M)
                except:
                    W = group.members[0].mid
                    M = Message()
                    M.to = msg.to
                    M.contentType = 13
                    M.contentMetadata = {'mid': W}
                    cl.sendMessage(M)
#-----------------------------------------------
            elif msg.text in ["Contact:on","K on","Contact on","é¡¯ç¤ºï¼šé–‹"]:
                if wait["contact"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["contact"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Contact:off","K off","Contact off","é¡¯ç¤ºï¼šé—œ"]:
                if wait["contact"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done ")
                else:
                    wait["contact"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
#-----------------------------------------------                    
            elif "message change:" == pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("message change:","")
                periksa['message'] = xres
                cl.sendText(msg.to,"Message changed to "+xres)
            elif "message cek" in pesan.lower():
                if periksa['message'] == "":
                    cl.sendText(msg.to,"Nothing 􀜁􀄶Not Bad􏿿")
                else:
                    cl.sendText(msg.to,"Message change to: \n"+str(periksa['message']))						
            elif "gift1" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'2821',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'4'}
                msg.text = None
                cl.sendMessage(msg)
            elif "gift2" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'3172',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'2'}
                msg.text == None
                cl.sendMessage(msg)
            elif "gift3" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'4333',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'3'}
                msg.text = None
                cl.sendMessage(msg)
            elif "gift4" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'3002',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'4'}
                msg.text = None
                cl.sendMessage(msg)
            elif "gift5" == pesan.lower():
                msg.contentType = 9
                msg.contentMetadata = { 'STKPKGID':'6083',
                                        'PRDTYPE':'STICKER',
                                        'MSGTPL':'1'}
                msg.text = None
                cl.sendMessage(msg)
            elif "voice:" in pesan.lower():
                xpesan = pesan.lower()
                xres = xpesan.replace("voice:","")
                tts = gTTS(text=xres, lang='id')
                path = '%s/pythonLine-vn.data' % (tempfile.gettempdir())
                ac = tts.save(path)
                cl.sendAudio(msg.to,path)
                os.remove(path) 
            elif "kontak: " in pesan.lower():
                   umid = pesan.replace('kontak: ','')
                   msg.contentType = 13
                   msg.text = None
                   msg.contentMetadata = {'mid': umid}
                   cl.sendMessage(msg)                

#-----------------------TAG------------------ RG				
            elif msg.text.lower() == 'tag':
                    group = cl.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    nm1,nm2,nm3,nm4,nm5,jml = [],[],[],[],[],len(nama)
                    if jml <=100:
                        MENTION(msg.to,nama)
                    elif jml > 100 and jml < 200:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,len(nama)-1):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                    elif jml > 200 and jml < 300:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,200):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                        for i in range(200,len(nama)-1):
                            nm3 += [nama[i]]
                        MENTION(msg.to,nm3)
                    elif jml > 300 and jml < 400:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,200):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                        for i in range(200,300):
                            nm3 += [nama[i]]
                        MENTION(msg.to,nm3)
                        for i in range(300,len(nama)-1):
                            nm4 += [nama[i]]
                        MENTION(msg.to,nm4)
                    elif jml > 400 and jml < 500:
                        for i in range(0,100):
                            nm1 += [nama[i]]
                        MENTION(msg.to,nm1)
                        for i in range(100,200):
                            nm2 += [nama[i]]
                        MENTION(msg.to,nm2)
                        for i in range(200,300):
                            nm3 += [nama[i]]
                        MENTION(msg.to,nm3)
                        for i in range(300,400):
                            nm4 += [nama[i]]
                        MENTION(msg.to,nm4)
                        for i in range(400,len(nama)-1):
                            nm5 += [nama[i]]
                        MENTION(msg.to,nm5)
#-----------------------------------------------
            elif "tagmem" == msg.text.lower():
                 group = cl.getGroup(msg.to)
                 nama = [contact.mid for contact in group.members]
                 nm1, nm2, nm3, nm4, nm5, jml = [], [], [], [], [], len(nama)
                 if jml <= 100:
                    summon(msg.to, nama)
                 if jml > 100 and jml < 200:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, len(nama)-1):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                 if jml > 200  and jml < 500:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, 199):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                    for k in range(200, 299):
                        nm3 += [nama[k]]
                    summon(msg.to, nm3)
                    for l in range(300, 399):
                        nm4 += [nama[l]]
                    summon(msg.to, nm4)
                    for m in range(400, len(nama)-1):
                        nm5 += [nama[m]]
                    summon(msg.to, nm5)
                 if jml > 500:
                     print ("Terlalu Banyak Men 500+")
                 cnt = Message()
                 cnt.text = "Jumlah:\n" + str(jml) +  " Members"
                 cnt.to = msg.to
                 cl.sendMessage(cnt)
            elif "Tag @" in pesan:
                _name = pesan.replace("Tag @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                        xname = g.displayName
                        xlen = str(len(xname)+1)
                        msg.contentType = 0
                        msg.text = "@"+xname+" "
                        msg.contentMetadata ={'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(g.mid)+'}]}','EMTVER':'4'}
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)
                        cl.sendMessage(msg)						
                    else:
                        pass

            elif "St " in pesan:
                txt=pesan.split(' ')
                bc = int(txt[2])
                _name = pesan.replace("St "+str(txt[1])+" "+str(bc)+" @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                        xname = g.displayName
                        xlen = str(len(xname)+1)
                        msg.contentType = 0
                        msg.text = "@"+xname+" "
                        msg.contentMetadata ={'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(g.mid)+'}]}','EMTVER':'4'}
                        if str(txt[1]) == "msg":
                            for x in range(bc):
                                cl.sendMessage(msg)						
#_______________________________________________________________          
                  
            elif "Sider on" in msg.text:
                try:
                    del cctv['point'][msg.to]
                    del cctv['sidermem'][msg.to]
                    del cctv['cyduk'][msg.to]
                except:
                    pass
                cctv['point'][msg.to] = msg.id
                cctv['sidermem'][msg.to] = ""
                cctv['cyduk'][msg.to]=True
                wait["Sider"] = True
                cl.sendText(msg.to,"Siap On Cek Sider")
                
            elif "Sider off" in msg.text:
                if msg.to in cctv['point']:
                    cctv['cyduk'][msg.to]=False
                    wait["Sider"] = False
                    cl.sendText(msg.to, "Cek Sider Off")
                else:
                    cl.sendText(msg.to, "Heh Belom Di Set")   
        
            elif "Gmember bc:" in pesan:
                xres = pesan.replace("Gmembers bc:","")
                group = cl.getGroup(msg.to)
                mem = [contact.mid for contact in group.members]
                cmem = cl.getContacts(mem)
                nc = ""
                for x in range(len(cmem)):
                  try:
                    cl.sendText(cmem[x].mid,xres)
                    nc += "\n" + cmem[x].displayName
                  except:
                    pass
                pass
                cl.sendText(msg.to,"Success BC to :\n%s\n\nTotal Members: %s"%(nc,str(len(cmem))))

            elif "Pesan set:" in msg.text:
                wait["message"] = msg.text.replace("Pesan set:","")
                cl.sendText(msg.to,"We changed the message")
            elif msg.text.lower() == 'pesan cek':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"Message set to: \n\n" + wait["message"])
                else:
                    cl.sendText(msg.to,"Message set to: \n\n" + wait["message"])
            elif "Comment set:" in msg.text:
                c = msg.text.replace("Comment set:","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"Error")
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"It was changed\n\n" + c)
            elif msg.text in ["Comment cek"]:
                cl.sendText(msg.to,"An automatic comment is established as follows at present。\n\n" + str(wait["comment"]))
            elif msg.text in ["コメント:オン","Comment:on"]:
                if wait["commentOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done")
                else:
                    wait["commentOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already")
            elif msg.text in ["コメント:オフ","Comment:off"]:
                if wait["commentOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done")
                else:
                    wait["commentOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already")                
#_______________________________________________________________ RG
            elif "selftime" in msg.text.lower():
                elpsd = datetime.now() - strt
                cl.sendText(msg.to,'Duration : %s'%(elpsd))
#-----------------------------------------------                        
            elif "Contact" in msg.text:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]                
                mmid = cl.getContact(key1)
                msg.contentType = 13
                msg.contentMetadata = {"mid": key1}
                cl.sendMessage(msg) 
#------------------------------------------------ 

            elif "Image " in msg.text:
                search = msg.text.replace("Image ","")
                url = 'https://www.google.com/search?espv=2&biw=1366&bih=667&tbm=isch&oq=kuc&aqs=mobile-gws-lite.0.0l5&q=' + search
                raw_html = (download_page(url))
                items = []
                items = items + (_images_get_all_items(raw_html))
                path = random.choice(items)
                try:
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass					
#-------------------------------------------------                
            elif "Say " in pesan:
                xres = pesan.replace("Say ","")
                k1.sendText(msg.to,xres)
                k2.sendText(msg.to,xres)
                k3.sendText(msg.to,xres)
                k4.sendText(msg.to,xres)
                k5.sendText(msg.to,xres)	
                k6.sendText(msg.to,xres)
                k7.sendText(msg.to,xres)
                k8.sendText(msg.to,xres)
                k9.sendText(msg.to,xres)
                k10.sendText(msg.to,xres)			
            elif "Group bc:" in pesan:
                xres = pesan.replace("Group bc:","")
                G = cl.getGroupIdsJoined()
                cgroup = cl.getGroups(G)
                ngroup = ""
                for x in range(len(cgroup)):
                    cl.sendText(cgroup[x].id,xres)
                    ngroup += "\n" + cgroup[x].name
                pass
                cl.sendText(msg.to,"Success BC to :\n%s\n\nTotal Group: %s"%(ngroup,str(len(cgroup))))
            elif "Contact bc:" in pesan:
                xres = pesan.replace("Cbc:","")
                C = cl.getAllContactIds()
                cmem = cl.getContacts(C)
                nc = ""
                for x in range(len(cmem)):
                    cl.sendText(cmem[x].mid,xres)
                    nc += "\n" + cmem[x].displayName
                pass
                cl.sendText(msg.to,"Success BC to :\n%s\n\nTotal Contact: %s"%(nc,str(len(cmem))))
            elif "PING" == pesan:
                try:
                    k1.findAndAddContactsByMid(msg.to)
                    k2.findAndAddContactsByMid(msg.to)
                    k3.findAndAddContactsByMid(msg.to)
                    k4.findAndAddContactsByMid(msg.to)
                    k5.findAndAddContactsByMid(msg.to)			

k6.findAndAddContactsByMid(msg.to)
                    k7.findAndAddContactsByMid(msg.to)
                    k8.findAndAddContactsByMid(msg.to)
                    k9.findAndAddContactsByMid(msg.to)
                    k10.findAndAddContactsByMid(msg.to)					
                except:
                    pass
                k1.sendText(msg.to,"PONG!!!")
                k2.sendText(msg.to,"PONG!!!")
                k3.sendText(msg.to,"PONG!!!")
                k4.sendText(msg.to,"PONG!!!")
                k5.sendText(msg.to,"PONG!!!")
                k6.sendText(msg.to,"PONG!!!")
                k7.sendText(msg.to,"PONG!!!")
                k8.sendText(msg.to,"PONG!!!")
                k9.sendText(msg.to,"PONG!!!")
                k10.sendText(msg.to,"PONG!!!")						
            elif msg.text.lower() == 'respon':
                profile = k1.getProfile()
                text = profile.displayName + ""
                k1.sendText(msg.to, text)
                profile = k2.getProfile()
                text = profile.displayName + ""
                k2.sendText(msg.to, text)
                profile = k3.getProfile()
                text = profile.displayName + ""
                k3.sendText(msg.to, text)
                profile = k4.getProfile()
                text = profile.displayName + ""
                k4.sendText(msg.to, text)
                profile = k5.getProfile()
                text = profile.displayName + ""
                k5.sendText(msg.to, text)
                profile = k6.getProfile()
                text = profile.displayName + ""
                k6.sendText(msg.to, text)
                profile = k7.getProfile()
                text = profile.displayName + ""
                k7.sendText(msg.to, text)
                profile = k8.getProfile()
                text = profile.displayName + ""
                k8.sendText(msg.to, text)
                profile = k9.getProfile()
                text = profile.displayName + ""
                k9.sendText(msg.to, text)
                profile = k10.getProfile()
                text = profile.displayName + ""
                k10.sendText(msg.to, text)
#            elif "FUCK" == pesan:
#                try:
#                    wb.findAndAddContactsByMid(msg.to)
#                    kk.findAndAddContactsByMid(msg.to)
#                except:
##                    pass
 #               cl.sendText(msg.to,"┌∩┐(◣_◢)┌∩┐")
 #               kk.sendText(msg.to,"┌∩┐(◣_◢)┌∩┐")
 #               wb.sendText(msg.to,"┌∩┐(◣_◢)┌∩┐")

            elif "mid @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                           cl.sendText(msg.to,str(mention['M']))
                        except Exception as e:
                            pass
            elif "ustatus @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            cl.sendText(msg.to,str(profile.statusMessage))
                        except Exception as e:
                            print (e)
            elif "uname @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            cl.sendText(msg.to,str(profile.displayName))
                        except Exception as e:
                            pass

            elif "upict @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getContact(mention['M'])
                            cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                        except Exception as e:
                            pass
							
            elif "ucover @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            cu = cl.channel.getCover(mention['M'])
                            cl.sendImageWithURL(msg.to,cu)
                            print("Done")
                        except Exception as e:
                            pass							
#--------------------------PICTURE---------------------- RG
            elif "Getall" in msg.text:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                path = str(cu)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                try:
                    cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nBio :\n" + contact.statusMessage)
                    cl.sendText(msg.to,"Profile Picture " + contact.displayName + "\n􀄃􀉛itu􏿿􀄃􀉛itu􏿿􀄃􀉛itu􏿿")
                    cl.sendImageWithURL(msg.to,image)
                    cl.sendText(msg.to,"Cover " + contact.displayName + "\n􀄃􀉛itu􏿿􀄃􀉛itu􏿿􀄃􀉛itu􏿿")
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass
					
            elif msg.text in ["Me pict"]:
                    profile = cl.getProfile()
                    h = cl.getContact(mid)
                    try:
                         cl.sendImageWithURL(msg.to, "http://dl.profile.line-cdn.net/" + profile.pictureStatus)
                         cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                    except:
                       pass
					   
            elif msg.text in ["Mycover"]:
                    h = cl.getContact(mid)
                    cu = cl.channel.getCover(mid)          
                    path = str(cu)
                    cl.sendImageWithURL(msg.to, path)

            elif "Myinfo" in msg.text:
                profile = cl.getProfile()
                h = cl.getContact(mid)
                cu = cl.channel.getCover(mid)
                path = str(cu)
                image = "http://dl.profile.line-cdn.net/" + profile.pictureStatus
                try:
                    cl.sendText(msg.to,"Nama :\n" + h.displayName + "\n\nStatus :\n" + h.statusMessage)
                    cl.sendText(msg.to,"Profile Picture " + h.displayName)
                    cl.sendImageWithURL(msg.to,image)
                    cl.sendText(msg.to,"Cover " + contact.displayName)
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass

            elif msg.text in ["Myame"]:
                    h = cl.getContact(mid)
                    cl.sendText(msg.to,"===[DisplayName]===\n" + h.displayName)
#-----------------------------------------
            elif msg.text in ["Mybio"]:
                    h = cl.getContact(mid)
                    cl.sendText(msg.to,"===[StatusMessage]===\n" + h.statusMessage)                                                                                 

#----------------TIMES---------------------------- RG
            elif msg.text in ["Times","Waktu"]:
                timeNow = datetime.now()
                timeHours = datetime.strftime(timeNow,"(%H:%M)")
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                inihari = datetime.today()
                hr = inihari.strftime('%A')
                bulan = inihari.strftime('%m')
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bulan == str(k): bulan = bulan[k-1]
                rst = hasil + ", " + inihari.strftime('%d') + " - " + bulan + " - " + inihari.strftime('%Y') + "\nJam : [ " + inihari.strftime('%H:%M:%S') + " ]"
                cl.sendText(msg.to, rst)
            elif msg.text in ["Tanggal"]:
                cl.sendText(msg.to,datetime.today().strftime('Tanggal (%d/%m/%Y)\nJam       (%H:%M:%S.wib)'))
#-------------------------------------------------- RG

            elif "reboot" == pesan.lower():
                cl.sendText(msg.to,"Rebooting")
                restart_program()

#            elif "me ticket" in pesan.lower():
#               tiket = cl._reissueUserTicket()
#               cl.sendText(msg.to, "line.me/ti/p/%20"+tiket)
            elif "mc: " in pesan.lower():
                   umid = pesan.replace('mc: ','')
                   msg.contentType = 13
                   msg.text = None
                   msg.contentMetadata = {'mid': umid}
                   cl.sendMessage(msg)	
            elif ".blank" in pesan:
                      msg.contentType = 13
                      msg.text = None
                      msg.contentMetadata = {'mid': "'"}
                      cl.sendMessage(msg)				   
            elif "Spam mc:" in pesan:
                xres = pesan.replace("Spam mc:","")
                if xres in helpMessage:
                    pass
                elif xres == "":
                    pass
                else:
                    periksa['chatspam'] = xres
                    with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendText(msg.to,"Chat for mc: %s"%(xres))
            elif "Group spam:" in pesan:
                xres = pesan.replace("Group spam:","")
                if xres in helpMessage:
                    pass
                elif xres == "":
                    pass
                else:
                    periksa['gsname'] = xres
                    with open('settingan.json', 'w') as fp:
                            json.dump(periksa, fp, sort_keys=True, indent=4)
                    cl.sendText(msg.to,"Group name for spam inv: %s"%(xres))
            elif "spam mc:on" == pesan.lower():
                if periksa["target"] == {}:
                    cl.sendText(msg.to,"Target not found 􀜁􀄶Not Bad􏿿")
                else:
                   mc = []
                   for mi_d in periksa["target"]:
                        mc.append(mi_d)
                   pass
                   k1.findAndAddContactsByMids(mc)
                   k2.findAndAddContactsByMids(mc)
                   k3.findAndAddContactsByMids(mc)
                   k4.findAndAddContactsByMids(mc)
                   k5.findAndAddContactsByMids(mc)				   
                   cl.sendText(msg.to,"Loading")
                   try:
                     k1.sendText(msg.to,"Loading")
                   except:
                       pass
                   try:
                     k2.sendText(msg.to,"Loading")
                   except:
                       pass
                   try:
                     k3.sendText(msg.to,"Loading")
                   except:
                       pass
                   try:
                     k4.sendText(msg.to,"Loading")
                   except:
                       pass
                   try:
                     k5.sendText(msg.to,"Loading")
                   except:
                       pass					   
                   for zx in range(0,100):
                     try:
                       room = k1.createRoom(mc)
                       roomId = room.mid
                       print (roomId)
                       for i in range(0,10):
                         print ('sendPesan')
                         k1.sendText(roomId,"%s"%(periksa['chatspam']))
                       k1.leaveRoom(roomId)
                     except Exception as E:
                         print (E)
                     try:
                       room = k2.createRoom(mc)
                       roomId = room.mid
                       print (roomId)
                       for i in range(0,10):
                           print ('sendPesan')
                           k2.sendText(roomId,"%s"%(periksa['chatspam']))
                       k2.leaveRoom(roomId)
                     except:
                         pass
                     try:
                       room = k3.createRoom(mc)
                       roomId = room.mid
                       print (roomId)
                       for i in range(0,10):
                           print ('sendPesan')
                           k3.sendText(roomId,"%s"%(periksa['chatspam']))
                       k3.leaveRoom(roomId)
                     except:
                         pass
                     try:
                       room = k4.createRoom(mc)
                       roomId = room.mid
                       print (roomId)
                       for i in range(0,10):
                           print ('sendPesan')
                           k4.sendText(roomId,"%s"%(periksa['chatspam']))
                       k4.leaveRoom(roomId)
                     except:
                         pass
                     try:
                       room = k5.createRoom(mc)
                       roomId = room.mid
                       print (roomId)
                       for i in range(0,10):
                           print ('sendPesan')
                           k5.sendText(roomId,"%s"%(periksa['chatspam']))
                       k5.leaveRoom(roomId)
                     except:
                         pass						 
                   cl.sendText(msg.to,"Done")
                   try:
                     k1.sendText(msg.to,"Done")
                   except:
                       pass
                   try:
                     k2.sendText(msg.to,"Done")
                   except:
                       pass
                   try:
                     k3.sendText(msg.to,"Done")
                   except:
                       pass
                   try:
                     k4.sendText(msg.to,"Done")
                   except:
                       pass
                   try:
                     k5.sendText(msg.to,"Done")
                   except:
                       pass				   
            elif "spaminv:on" == pesan.lower():
                if periksa["target"] == {}:
                    cl.sendText(msg.to,"Target not found 􀜁􀄶Not Bad􏿿")
                else:
                   mc = []
                   for mi_d in periksa["target"]:
                        mc.append(mi_d)
                   pass
                   k1.findAndAddContactsByMids(mc)
                   k2.findAndAddContactsByMids(mc)
                   k3.findAndAddContactsByMids(mc)
                   k4.findAndAddContactsByMids(mc)
                   k5.findAndAddContactsByMids(mc)				   
                   cl.sendText(msg.to,"Loading")
                   for zx in range(0,400):
                      try:
                        k1.createGroup(periksa['gsname'],mc)
                      except:
                         pass
                      try:
                        k2.createGroup(periksa['gsname'],mc)
                      except:
                         pass
                      try:
                        k3.createGroup(periksa['gsname'],mc)
                      except:
                         pass
                      try:
                        k4.createGroup(periksa['gsname'],mc)
                      except:
                         pass
                      try:
                        k5.createGroup(periksa['gsname'],mc)
                      except:
                         pass					 
                   cl.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
                   G = k1.getGroupIdsJoined()
                   G1 = k2.getGroupIdsJoined()
                   G2 = k3.getGroupIdsJoined()
                   G3 = k4.getGroupIdsJoined()
                   G4 = k5.getGroupIdsJoined()			   
                   cgroup1 = k1.getGroups(G)
                   cgroup2 = k2.getGroups(G1)
                   cgroup3 = k3.getGroups(G2)
                   cgroup4 = k4.getGroups(G3)
                   cgroup5 = k5.getGroups(G4)				   
                   ngroup1 = []
                   ngroup2 = []
                   ngroup3 = []
                   ngroup4 = []
                   ngroup5 = []		   
                   for x in range(len(cgroup1)):
                       if cgroup1[x].name == periksa['gsname']:
                          ngroup1.append(cgroup1[x].name)
                   for x in range(len(cgroup2)):
                       if cgroup2[x].name == periksa['gsname']:
                          ngroup2.append(cgroup2[x].name)
                   for x in range(len(cgroup3)):
                       if cgroup3[x].name == periksa['gsname']:
                          ngroup3.append(cgroup3[x].name)
                   for x in range(len(cgroup4)):
                       if cgroup4[x].name == periksa['gsname']:
                          ngroup4.append(cgrou4[x].name)
                   for x in range(len(cgroup5)):
                       if cgroup5[x].name == periksa['gsname']:
                          ngroup5.append(cgrou5[x].name)						  
            elif "Spam:" in pesan:
                   lol = pesan.replace('Spam:','')
                   hehe = lol.split("@")
                   cl.sendText(msg.to,"Spamming >> "+str(hehe[1])+"\nGroups Name:"+str(hehe[0]))
                   k1.findAndAddContactsByMid(hehe[1])
                   k2.findAndAddContactsByMid(hehe[1])
                   k3.findAndAddContactsByMid(hehe[1])
                   k4.findAndAddContactsByMid(hehe[1])
                   k5.findAndAddContactsByMid(hehe[1])				   
                   for zx in range(0,400):
                     try:
                       k1.createGroup(str(hehe[0]),[hehe[1]])
                     except:
                         pass
                     try:
                       k2.createGroup(str(hehe[0]),[hehe[1]])
                     except:
                         pass
                     try:
                       k3.createGroup(str(hehe[0]),[hehe[1]])
                     except:
                         pass
                     try:
                       k4.createGroup(str(hehe[0]),[hehe[1]])
                     except:
                         pass
                     try:
                       k5.createGroup(str(hehe[0]),[hehe[1]])
                     except:
                         pass						 
                   cl.sendText(msg.to,"Done 􀜁􀄯ok􏿿")

            elif "Leave:" in pesan:
                group_name = pesan.replace('Leave:','')
                G = cl.getGroupIdsJoined()
                cgroup = cl.getGroups(G)
                for x in range(len(cgroup)):
                  if group_name == cgroup[x].name:
                      try:
                         cl.leaveGroup(cgroup[x].id)
                      except:
                          pass
                      try:
                         k1.leaveGroup(cgroup[x].id)
                      except:
                          pass
                      try:
                         k2.leaveGroup(cgroup[x].id)
                      except:
                          pass
                      try:
                         k3.leaveGroup(cgroup[x].id)
                      except:
                          pass
                      try:
                         k4.leaveGroup(cgroup[x].id)
                      except:
                          pass
                      try:
                         k5.leaveGroup(cgroup[x].id)
                      except:
                          pass						  
                cl.sendText(msg.to,"Done 􀜁􀄯ok􏿿")
#---------------------------------------------------------
            elif pesan.lower() == "notag":
                if notag:
                    notag = False
                    cl.sendText(msg.to,"Notag disabled")
                else:
                    notag = True
                    cl.sendText(msg.to,"Notag enabled.")
            elif "Pictgroup" in pesan:
                  group = cl.getGroup(msg.to)
                  path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                  cl.sendImageWithURL(msg.to,path)	
					
#---------------------------------------------------------				
            elif pesan.lower().startswith("wban "):
                wban = pesan.lower().replace("wban","").lstrip().rstrip()
                wbanlist.append(wban)
                cl.sendText(msg.to,"%s is now blacklisted."%wban)
            elif pesan.lower().startswith("wunban "):
                wunban = pesan.lower().replace("wunban","").lstrip().rstrip()
                if wunban in wbanlist:
                    wbanlist.remove(wunban)
                    cl.sendText(msg.to,"%s is no longer blacklisted."%wunban)
                else:
                    cl.sendText(msg.to,"%s is not blacklisted."%wunban)
            elif pesan.lower() == 'wbanlist':
                tst = "Word banlist:\n"
                if len(wbanlist) > 0:
                    for word in wbanlist:
                        tst += "\n- %s"%word
                    cl.sendText(msg.to,tst)
                else:
                    cl.sendText(msg.to,"Wbanlist is empty!")
            elif pesan.lower() == 'invite:on':
                inviting = True
                cl.sendText(msg.to,"Send a contact to invite.")
				
#-------------------------WELCOME--------------
 #==========================================================         
            elif "Upwelcome: " in msg.text:
                wait["welmsg"] = msg.text.replace("Upwelcome: ","")
                cl.sendText(msg.to,"update welcome message succes")
            elif msg.text in ["Check welcome"]:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"welcome  message\n\n" + wait["welmsg"])
                else:
                    cl.sendText(msg.to,"The automatic appending information is set as followsÃ£â‚¬â€š\n\n" + wait["welmsg"])
            elif msg.text in ["Welcome:on"]:
                if wait["welcomeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"welcome message on")
                    else:
                        cl.sendText(msg.to,"welcome already on")
                else:
                    wait["welcomeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"welcome message on")
                    else:
                        cl.sendText(msg.to,"welcome already on")     
            elif msg.text in ["Welcome:off"]:
                if wait["welcomeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"welcome message off")
                    else:
                        cl.sendText(msg.to,"welcome already off")
                else:
                    wait["welcomeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"welcome message off")
                    else:
                        cl.sendText(msg.to,"welcome already off")               
#--------------------------------------------------                     
            elif msg.text.lower() == 'welcome':
                ginfo = cl.getGroup(msg.to)
                cl.sendImageWithURL(msg.to,"http://www.imgion.com/images/01/Kids-are-welcoming-you.jpeg")
                cl.sendText(msg.to,"Owner Grup " + str(ginfo.name) + " :" )
                try:
                    group = cl.getGroup(msg.to)
                    GS = group.creator.mid
                    M = Message()
                    M.to = msg.to
                    M.contentType = 13
                    M.contentMetadata = {'mid': GS}
                    cl.sendMessage(M)
                except:
                    W = group.members[0].mid
                    M = Message()
                    M.to = msg.to
                    M.contentType = 13
                    M.contentMetadata = {'mid': W}
                    cl.sendMessage(M)

#-----------------------------------------------------------
#---------------------------------------------------------
            elif "Spammed @" in msg.text:
                _name = msg.text.replace("Spammed @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                       cl.sendText(msg.to,"On the way\n\n"+ datetime.today().strftime('%H:%M:%S'))
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")
                       k1.sendText(g.mid,"Spam 😂")
                       k2.sendText(g.mid,"Spam 😂")
                       k3.sendText(g.mid,"Spam 😂")
                       k4.sendText(g.mid,"Spam 😂")
                       k5.sendText(g.mid,"Spam 😂")					   
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM ??")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k1.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k2.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k3.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k4.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       k5.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")					   
                       cl.sendText(msg.to, "ƊƠƝЄ Spammed\n\n"+ datetime.today().strftime('%H:%M:%S'))
#---------------------------------------------------------						

#===============[Tranlate Command]====================
            elif "Translate" == pesan:
                try:
                  k1.sendText(msg.to,"Command Translate:\n\n Tr-id to Indonesia \n Tr-th to Thai \n Tr-en to English \n Tr-ja to Japan \n Tr-ms to Malay \n Tr-jw to Jawa \n Tr-it to Italia \n Tr-my to Myanmar \n Tr-fr to French \n Tr-ar to Arabic")
                except:
                   try:
                      k2.sendText(msg.to,"Command Translate:\n\n Tr-id to Indonesia \n Tr-th to Thai \n Tr-en to English \n Tr-ja to Japan \n Tr-ms to Malay \n Tr-jw to Jawa \n Tr-it to Italia \n Tr-my to Myanmar \n Tr-fr to French \n Tr-ar to Arabic")
                   except:
                       cl.sendText(msg.to,"Assists must exist in the group")
            elif "Tr-id" in pesan:
                 xres = pesan.replace("Tr-id","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'id')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-en" in pesan:
                 xres = pesan.replace("Tr-en","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'en')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-ja" in pesan:
                 xres = pesan.replace("Tr-ja","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'ja')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-th" in pesan:
                 xres = pesan.replace("Tr-th","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'th')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-jw" in pesan:
                 xres = pesan.replace("Tr-jw","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'jw')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-ar" in pesan:
                 xres = pesan.replace("Tr-ar","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'ar')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-ms" in pesan:
                 xres = pesan.replace("Tr-ms","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'ms')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-my" in pesan:
                 xres = pesan.replace("Tr-my","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'my')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-it" in pesan:
                 xres = pesan.replace("Tr-it","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'it')
                 cl.sendText(msg.to,str(trans))
            elif "Tr-fr" in pesan:
                 xres = pesan.replace("Tr-fr","")
                 xres1 = xres.lstrip()
                 xres2 = xres1.replace("","")
                 xres3 = xres2.rstrip()
                 _text = xres3
                 trans = translate(_text,'fr')
                 cl.sendText(msg.to,str(trans))

            elif "Wiki:" in pesan:
                cari = pesan.replace('Wiki:','')
                wikipedia.set_lang("id")
                try:
                   ny = wikipedia.summary(cari)
                except Exception as ny:
          
                  cl.sendText(msg.to,"%s"%(ny))     
            elif "Urban:" in pesan:
               cari = pesan.replace('Urban:','')
               try:
                 response = requests.get("http://api.urbandictionary.com/v0/define?term="+cari)
                 data = response.json()
                 num_requested = 0
                 term_list = data['list']
                 num_requested = min(num_requested, len(term_list) - 1)
                 num_requested = max(0, num_requested)
                 definition = term_list[num_requested].get('definition')
                 example = term_list[num_requested].get('example')
                 cl.sendText(msg.to,"Definition:\n\n%s\n\nExample:\n\n%s"%(definition,example))
               except:
                 cl.sendText(msg.to,"Error")
                
            elif "Pict ig " in pesan:
               cari = pesan.replace('Pict ig ','')
               if cari not in helpMessage:
                 try:
                   response = requests.get(cari+"?__a=1")
                   data = response.json()
                   ig_url = data['graphql']['shortcode_media']['display_url']
                   cl.sendImageWithURL(msg.to,ig_url)
                 except Exception as E:
                   cl.sendText(msg.to,"Error")
            elif "vid IG " in pesan:
               cari = pesan.replace('vid IG ','')
               if cari not in helpMessage:
                 try:
                   response = requests.get(cari+"?__a=1")
                   data = response.json()
                   ig_url = data['graphql']['shortcode_media']['display_url']
                   cl.sendVideoWithURL(msg.to,ig_url)
                 except Exception as E:
                   cl.sendText(msg.to,"Error")
            elif "all pict" == pesan.lower():
                if msg.toType == 2:
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if g.mid not in Bots:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Target not found")
                    else:
                        for target in targets:
                            try:
                                profile = cl.getContact(target)
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                            except:
                                pass
#===============[Assist Command]====================
            elif "Mystatus: " in msg.text:
                string = msg.text.replace("Mystatus: ","")
                if len(string) <= 500:
                    profile = cl.getProfile()
                    profile.statusMessage = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"display message: \n\n" + string)
            elif "K1 upstatus: " in msg.text:
                string = msg.text.replace("K1 upstatus: ","")
                if len(string) <= 500:
                    profile_B = k1.getProfile()
                    profile_B.statusMessage = string
                    k1.updateProfile(profile_B)
                    k1.sendText(msg.to,"display message: \n\n" + string)
            elif "K2 upstatus: " in msg.text:
                string = msg.text.replace("K2 upstatus: ","")
                if len(string) <= 500:
                    profile_C = k2.getProfile()
                    profile_C.statusMessage = string
                    k2.updateProfile(profile_C)
                    k2.sendText(msg.to,"display message: \n\n" + string)
            elif "K3 upstatus: " in msg.text:
                string = msg.text.replace("K3 upstatus: ","")
                if len(string) <= 500:
                    profile_C = k3.getProfile()
                    profile_C.statusMessage = string
                    k3.updateProfile(profile_C)
                    k3.sendText(msg.to,"display message: \n\n" + string)
            elif "K4 upstatus: " in msg.text:
                string = msg.text.replace("K4 upstatus: ","")
                if len(string) <= 500:
                    profile_C = k4.getProfile()
                    profile_C.statusMessage = string
                    k4.updateProfile(profile_C)
                    k4.sendText(msg.to,"display message: \n\n" + string)
            elif "K5 upstatus: " in msg.text:
                string = msg.text.replace("K5 upstatus: ","")
                if len(string) <= 500:
                    profile_C = k5.getProfile()
                    profile_C.statusMessage = string
                    k5.updateProfile(profile_C)
                    k5.sendText(msg.to,"display message: \n\n" + string)
#-------------------------------------------------------					
            elif "Changename: " in msg.text:
                string = msg.text.replace("Changename: ","")
                if len(string) <= 20:
                    profile = cl.getProfile()
                    profile.displayName = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"Name updated to %s"%string)
#--------------------------------------------------------
            elif "K1 rename: " in msg.text:
                string = msg.text.replace("K1 rename: ","")
                if len(string) <= 20:
                    profile = k1.getProfile()
                    profile.displayName = string
                    k1.updateProfile(profile)
                    k1.sendText(msg.to,"Name updated " + string)
#--------------------------------------------------------
            elif "K2 rename: " in msg.text:
                string = msg.text.replace("K2 rename: ","")
                if len(string) <= 20:
                    profile = k2.getProfile()
                    profile.displayName = string
                    k2.updateProfile(profile)
                    k2.sendText(msg.to,"Name updated " + string)
#--------------------------------------------------------
            elif "K3 rename: " in msg.text:
                string = msg.text.replace("K3 rename: ","")
                if len(string) <= 20:
                    profile = k3.getProfile()
                    profile.displayName = string
                    k3.updateProfile(profile)
                    k3.sendText(msg.to,"Name updated " + string)
#--------------------------------------------------------
            elif "K4 rename: " in msg.text:
                string = msg.text.replace("K4 rename: ","")
                if len(string) <= 20:
                    profile = k4.getProfile()
                    profile.displayName = string
                    k4.updateProfile(profile)
                    k4.sendText(msg.to,"Name updated " + string)
#--------------------------------------------------------
            elif "K5 rename: " in msg.text:
                string = msg.text.replace("K5 rename: ","")
                if len(string) <= 20:
                    profile = k5.getProfile()
                    profile.displayName = string
                    k5.updateProfile(profile)
                    k5.sendText(msg.to,"Name updated " + string)					
#---------------------------------------------------------					
#--------------------------------------------------------
            elif "K6 rename: " in msg.text:
                string = msg.text.replace("K1 rename: ","")
                if len(string) <= 20:
                    profile = k6.getProfile()
                    profile.displayName = string
                    k6.updateProfile(profile)
                    k6.sendText(msg.to,"Name updated " + string)
#--------------------------------------------------------
            elif "K7 rename: " in msg.text:
                string = msg.text.replace("K2 rename: ","")
                if len(string) <= 20:
                    profile = k7.getProfile()
                    profile.displayName = string
                    k7.updateProfile(profile)
                    k7.sendText(msg.to,"Name updated " + string)
#--------------------------------------------------------
            elif "K8 rename: " in msg.text:
                string = msg.text.replace("K3 rename: ","")
                if len(string) <= 20:
                    profile = k8.getProfile()
                    profile.displayName = string
                    k8.updateProfile(profile)
                    k8.sendText(msg.to,"Name updated " + string)
#--------------------------------------------------------
            elif "K9 rename: " in msg.text:
                string = msg.text.replace("K4 rename: ","")
                if len(string) <= 20:
                    profile = k9.getProfile()
                    profile.displayName = string
                    k9.updateProfile(profile)
                    k9.sendText(msg.to,"Name updated " + string)
#--------------------------------------------------------
            elif "K10 rename: " in msg.text:
                string = msg.text.replace("K5 rename: ","")
                if len(string) <= 20:
                    profile = k10.getProfile()
                    profile.displayName = string
                    k10.updateProfile(profile)
                    k10.sendText(msg.to,"Name updated " + string)					
#---------------------------------------------------------					
            elif "runtime" in pesan.lower():
                elpsd = datetime.now() - strt
                cl.sendText(msg.to,'Duration : %s'%(elpsd))
            elif "mybackup" in pesan.lower():
                cl.updateDisplayPicture(backup.pictureStatus)
                cl.updateProfile(backup)
                cl.sendText(msg.to,"Restore succes")				
            elif "copy @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = cl.getProfile()
                            backup.displayName = profile.displayName
                            backup.statusMessage = profile.statusMessage
                            backup.pictureStatus = profile.pictureStatus
                            cl.cloneContactProfile(mention['M'])
                            cl.sendText(msg.to,"Done")
                        except Exception as error:
                            pass					
            elif "k1 backup" in pesan.lower():
                k1.updateDisplayPicture(backup1.pictureStatus)
                k1.updateProfile(backup1)
                k1.sendText(msg.to,"Restore succes")				
            elif "k2 backup" in pesan.lower():
                k2.updateDisplayPicture(backup2.pictureStatus)
                k2.updateProfile(backup2)
                k2.sendText(msg.to,"Restore succes")				
            elif "k3 backup" in pesan.lower():
                k3.updateDisplayPicture(backup3.pictureStatus)
                k3.updateProfile(backup3)
                k3.sendText(msg.to,"Restore succes")				
            elif "k4 backup" in pesan.lower():
                k4.updateDisplayPicture(backup4.pictureStatus)
                k4.updateProfile(backup4)
                k4.sendText(msg.to,"Restore succes")				
            elif "k5 backup" in pesan.lower():
                k5.updateDisplayPicture(backup5.pictureStatus)
                k5.updateProfile(backup5)
                k5.sendText(msg.to,"Restore succes")								
            elif "k1 copy @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = k1.getProfile()
                            backup1.displayName = profile.displayName
                            backup1.statusMessage = profile.statusMessage
                            backup1.pictureStatus = profile.pictureStatus
                            k1.cloneContactProfile(mention['M'])
                            k1.sendText(msg.to,"Copy succes")
                        except Exception as error:
                            print (error)
            elif "k2 copy @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = k2.getProfile()
                            backup2.displayName = profile.displayName
                            backup2.statusMessage = profile.statusMessage
                            backup2.pictureStatus = profile.pictureStatus
                            k2.cloneContactProfile(mention['M'])
                            k2.sendText(msg.to,"Copy succes")
                        except Exception as error:
                            print (error)
            elif "k3 copy @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = k3.getProfile()
                            backup3.displayName = profile.displayName
                            backup3.statusMessage = profile.statusMessage
                            backup3.pictureStatus = profile.pictureStatus
                            k3.cloneContactProfile(mention['M'])
                            k3.sendText(msg.to,"Copy succes")
                        except Exception as error:
                            print (error)
            elif "k4 copy @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = k4.getProfile()
                            backup4.displayName = profile.displayName
                            backup4.statusMessage = profile.statusMessage
                            backup4.pictureStatus = profile.pictureStatus
                            k4.cloneContactProfile(mention['M'])
                            k4.sendText(msg.to,"Copy succes")
                        except Exception as error:
                            print (error)
            elif "k5 copy @" in pesan.lower():
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    names = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        try:
                            profile = k5.getProfile()
                            backup5.displayName = profile.displayName
                            backup5.statusMessage = profile.statusMessage
                            backup5.pictureStatus = profile.pictureStatus
                            k5.cloneContactProfile(mention['M'])
                            k5.sendText(msg.to,"Copy succes")
                        except Exception as error:
                            print (error)							
                
        if op.type == 59:
            print (op)


    except Exception as error:
        print (error)


def autolike():
     like = 1000+periksa['like']
     koment = periksa['comment']
     for zx in range(0,20):
        hasil = cl.activity(limit=20)
        if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
          try:    
            cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=like)
            cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],koment+"Autolike by: ✍ŤẸÃϻ Ж ĤÃЌβỖŤ✈")
            #print "Like"
          except:
            pass
        else:
            print ("Already Liked")

def download(url):
    file_name = url.split("/")[-1] + '.jpg'
    req = urllib.request.Request(url, headers={"User-Agent": "Line/8.0.0"})
    r = urllib.request.urlopen( req )
    i = Image.open(io.BytesIO(r.read()))
    i.save(file_name)
    return file_name

def a2():
    now2 = datetime.now()
    nowT = datetime.strftime(now2,"%M")
    if nowT[14:] in ["10","20","30","40","50","00"]:
        return False
    else:
        return True
		
def resetchat():
    while True:
        try:
            if periksa['autolike'] == True:
              autolike()
              time.sleep(300)
              autolike()
              time.sleep(300)
              autolike()
              time.sleep(300)
              autolike()
              time.sleep(300)
              autolike()
              time.sleep(200)
            else:
                pass
            k5.removeAllMessages(k1mid)
            #print "reset"
            time.sleep(400)
        except:
            pass
thread2 = threading.Thread(target=resetchat)
thread2.daemon = True
thread2.start()
#thread2.join()
threads = []		
while True:
  try:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 50)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev.decode))
    

    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)      
         
  except Exception as E:
      print (E)
